# TVBox TV 版（由 TVBox.Desktop-0.1.0-x64.exe 移植）

这是把 `TVBox.Desktop-0.1.0-x64.exe`（一个 Electron + React 写的 Windows 影视聚合客户端）移植到 **Android TV** 的工程。

## 它是怎么来的

原 exe 是 NSIS 安装包，里面是 Electron 44 应用。拆开 `resources/app.asar` 后得到：

| 部分 | 原实现 | 安卓版处理 |
|------|--------|-----------|
| 界面 | React 19 + artplayer/hls.js | **原样复用**，塞进 WebView |
| 业务逻辑 | Node.js 主进程 3169 行（爬虫、视频源、直播、搜索、收藏等 44 个接口） | 用兼容层打包成浏览器 JS，在 WebView 里跑 |
| 文件存储 | 本地 JSON 文件 | 映射到 localStorage |
| 网络请求 | Node fetch（无跨域限制） | 原生 HTTP 桥接绕过 CORS |
| 外部播放器 | 调用 Windows 播放器 | Android Intent |
| 遥控器 | 无（鼠标键盘） | 新增 DPAD 方向键/确认键焦点导航 |

**核心逻辑（片源订阅、点播、直播、搜索、收藏历史）完整保留**，只是换了运行外壳。

## 编译出 APK

本机没有 Android 编译环境，用 **GitHub Actions 云编译**（免费）：

1. 把这个文件夹里的所有内容，作为一个新仓库上传到 GitHub（新仓库 → 上传文件，或 `git init && git push`）。
2. 进入仓库的 **Actions** 标签页，找到 `Build TVBox Android TV APK`，点击 **Run workflow**。
3. 等几分钟编译完成，在本次运行页面底部的 **Artifacts** 下载 `TVBox-TV-APK`。
4. 解压得到 `TVBox-TV-arm64.apk`，这就是可安装的安卓 TV 版。

> 想本地编译的话：装 Android Studio（或 JDK17 + Android SDK platform 35），在 `android/` 目录执行 `gradle assembleDebug`，产物在 `android/app/build/outputs/apk/debug/`。

## 安装到电视

- **U 盘**：把 apk 拷进 U 盘，插到电视，用电视的文件管理器 / 当贝市场打开安装（需允许"未知来源"）。
- **adb**：`adb install TVBox-TV-arm64.apk`（需电视开启 USB 调试并同网）。

装好后是标准 Leanback TV 应用，出现在电视的应用栏里，用遥控器操作。

## 首次使用

1. 打开应用 → 进入"设置/片源"。
2. 导入你的视频源订阅地址（原软件支持的 CMS/JSON 订阅格式都兼容）。
3. 回到首页即可看到片源，用遥控器方向键移动焦点、确认键播放。

## 已知限制

- **AI 总结**（`ai:summary`）依赖外部大模型 API Key，接口保留了但需要在设置里配置后端；没有 Key 时该功能不可用，不影响看片。
- **外部播放器探测**（`player:detect`）原为 Windows 注册表/本地端口探测，TV 上返回空；点播优先用内置 hls.js 播放器。
- **配置文件选择**（`sources:pickFile`）在 TV 上退化为取消，建议直接用订阅地址而非本地文件。
- 这是**核心功能移植版**，界面沿用原桌面端布局（针对鼠标设计的密集布局在电视上可能字号偏小），后续可做 TV 专属大屏 UI 适配。

## 工程结构

```
TVBox-Android-TV/
├── web/
│   ├── renderer/          # React 前端（原样）+ 遥控器导航 + fetch 桥接
│   └── bridge/            # 主进程移植：shims/ 兼容层 + build.js 打包脚本
├── android/               # Android 工程（WebView 宿主 + 原生桥接）
└── .github/workflows/     # 云编译配置
```

分析记录见 `/Users/guanghao/Desktop/tv/.workbuddy/memory/2026-11-18.md`。

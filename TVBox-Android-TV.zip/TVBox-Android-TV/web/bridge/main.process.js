"use strict";
const electron = require("electron");
const node_fs = require("node:fs");
const node_path = require("node:path");
const cheerio = require("cheerio");
const iconv = require("iconv-lite");
const node_crypto = require("node:crypto");
const promises = require("node:fs/promises");
const node_net = require("node:net");
const node_child_process = require("node:child_process");
function _interopNamespaceDefault(e) {
  const n = Object.create(null, { [Symbol.toStringTag]: { value: "Module" } });
  if (e) {
    for (const k in e) {
      if (k !== "default") {
        const d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: () => e[k]
        });
      }
    }
  }
  n.default = e;
  return Object.freeze(n);
}
const cheerio__namespace = /* @__PURE__ */ _interopNamespaceDefault(cheerio);
const IPC = {
  appInfo: "app:info",
  openExternal: "app:open-external",
  settingsGet: "settings:get",
  settingsSet: "settings:set",
  sourcesList: "sources:list",
  sourcesAdd: "sources:add",
  sourcesUpdate: "sources:update",
  sourcesRemove: "sources:remove",
  sourcesSync: "sources:sync",
  sourcesSyncAll: "sources:sync-all",
  sourcesPickFile: "sources:pick-file",
  sourcesPresets: "sources:presets",
  sourcesAddPreset: "sources:add-preset",
  sitesList: "sites:list",
  sitesSetEnabled: "sites:set-enabled",
  sitesSetAllEnabled: "sites:set-all-enabled",
  sitesTest: "sites:test",
  searchRun: "search:run",
  searchCancel: "search:cancel",
  /** 主进程 → 渲染进程：每完成一个站点推一次 */
  searchProgress: "search:progress",
  detailGet: "detail:get",
  categoryList: "category:list",
  categoryBrowse: "category:browse",
  liveLoad: "live:load",
  liveResolve: "live:resolve",
  /** 读线路体检缓存 */
  liveHealth: "live:health",
  /** 体检一批线路（点开频道时懒体检 / 切分组时预热） */
  liveProbe: "live:probe",
  liveClearHealth: "live:clear-health",
  libraryGet: "library:get",
  libraryToggleFavorite: "library:toggle-favorite",
  libraryRemoveFavorite: "library:remove-favorite",
  libraryClearFavorites: "library:clear-favorites",
  libraryRecord: "library:record",
  libraryRemoveHistory: "library:remove-history-group",
  libraryClearHistory: "library:clear-history",
  playerDetect: "player:detect",
  playerOpen: "player:open",
  parseList: "parse:list",
  parseResolve: "parse:resolve",
  parseTest: "parse:test",
  parseAdd: "parse:add",
  parseRemove: "parse:remove",
  parseResetStats: "parse:reset-stats",
  /** 首页内容位。force=true 时忽略缓存重新拉一遍 */
  homeSections: "home:sections",
  aiSummary: "ai:summary",
  /** 带上从播放器里抽出来的画面，让模型真的看一遍 */
  aiSummaryVisual: "ai:summary-visual"
};
const PLACEHOLDERS = [
  ["ac", /\{ac\}/g],
  ["wd", /\{(wd|kw|key|keyword)\}/g],
  ["pg", /\{(pg|page)\}/g],
  ["t", /\{(t|type|typeid|class)\}/g],
  ["ids", /\{(ids|id)\}/g]
];
function buildCmsUrl(site, query) {
  const api = site.api ?? "";
  let templated = false;
  let url = api;
  for (const [key, re] of PLACEHOLDERS) {
    if (re.test(url)) {
      templated = true;
      const value = query[key];
      url = url.replace(re, value === void 0 ? "" : encodeURIComponent(String(value)));
    }
  }
  if (templated) {
    let out = url.replace(/\{h\}/g, String(query.h ?? ""));
    if (query.ids !== void 0 && !/[?&]ids=/.test(out)) {
      const sep2 = out.includes("?") ? out.endsWith("?") || out.endsWith("&") ? "" : "&" : "?";
      out = `${out}${sep2}ids=${encodeURIComponent(String(query.ids))}`;
    }
    return out;
  }
  const params = new URLSearchParams();
  if (query.ac) params.set("ac", query.ac);
  if (query.wd !== void 0) params.set("wd", query.wd);
  if (query.pg !== void 0) params.set("pg", String(query.pg));
  if (query.t !== void 0 && query.t !== "") params.set("t", String(query.t));
  if (query.ids !== void 0) params.set("ids", String(query.ids));
  const qs = params.toString();
  if (!qs) return url;
  const sep = url.includes("?") ? url.endsWith("?") || url.endsWith("&") ? "" : "&" : "?";
  return `${url}${sep}${qs}`;
}
function buildCmsBrowseUrl(site, ac, types, pg) {
  const api = site.api ?? "";
  const templated = /\{(ac|wd|kw|key|keyword|pg|page|t|type|typeid|class|ids|id|h)\}/.test(api);
  if (templated) {
    return buildCmsUrl(site, { ac, t: types[0] ?? "", pg });
  }
  const params = new URLSearchParams();
  params.set("ac", ac);
  for (const t of types) if (t) params.append("t", t);
  params.set("pg", String(pg));
  const sep = api.includes("?") ? api.endsWith("?") || api.endsWith("&") ? "" : "&" : "?";
  return `${api}${sep}${params.toString()}`;
}
function isCmsOk(payload) {
  if (!payload || typeof payload !== "object") return false;
  const code = payload.code;
  if (code === void 0 || code === null || code === "") return true;
  const s = String(code).toLowerCase();
  return s === "1" || s === "true" || s === "ok" || s === "success" || s === "200";
}
function asArray(value) {
  if (Array.isArray(value)) return value;
  if (value && typeof value === "object") return [value];
  return [];
}
const DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";
function detectEncoding(buffer, contentType, forced) {
  if (forced) return forced;
  const fromHeader = /charset=["']?([\w-]+)/i.exec(contentType)?.[1];
  if (fromHeader) return fromHeader.toLowerCase();
  const head = buffer.subarray(0, 4096).toString("latin1");
  const meta = /<meta[^>]+charset=["']?([\w-]+)/i.exec(head)?.[1] ?? /<\?xml[^>]+encoding=["']([\w-]+)["']/i.exec(head)?.[1];
  return meta ? meta.toLowerCase() : "utf-8";
}
async function request(url, options = {}) {
  const timeoutMs = (options.timeout ?? 20) * 1e3;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const headers = {
      "User-Agent": DEFAULT_UA,
      Accept: "*/*",
      ...options.header ?? {}
    };
    const res = await fetch(url, {
      method: options.method ?? "GET",
      headers,
      body: options.body,
      redirect: "follow",
      signal: controller.signal
    });
    const buffer = Buffer.from(await res.arrayBuffer());
    const flatHeaders = {};
    res.headers.forEach((v, k) => {
      flatHeaders[k] = v;
    });
    if (!res.ok && !options.allowHttpError) {
      throw new Error(`HTTP ${res.status} ${res.statusText}`);
    }
    return { ok: res.ok, status: res.status, finalUrl: res.url || url, headers: flatHeaders, buffer };
  } catch (err) {
    const e = err;
    if (e.name === "AbortError") throw new Error(`请求超时（${timeoutMs / 1e3}s）`);
    throw new Error(e.message || "网络请求失败");
  } finally {
    clearTimeout(timer);
  }
}
async function fetchText(url, options = {}) {
  const res = await request(url, options);
  return decodeResponse(res, options.encoding);
}
function decodeResponse(res, forced) {
  const contentType = res.headers["content-type"] ?? "";
  const encoding = detectEncoding(res.buffer, contentType, forced);
  if (encoding === "utf-8" || encoding === "utf8") return res.buffer.toString("utf-8");
  if (!iconv.encodingExists(encoding)) return res.buffer.toString("utf-8");
  return iconv.decode(res.buffer, encoding);
}
async function fetchJson(url, options = {}) {
  const text = await fetchText(url, options);
  return parseLooseJson(text);
}
function parseLooseJson(text) {
  const cleaned = text.replace(/^\uFEFF/, "").trim();
  try {
    return JSON.parse(cleaned);
  } catch {
    const start = cleaned.indexOf("{");
    const end = cleaned.lastIndexOf("}");
    if (start >= 0 && end > start) return JSON.parse(cleaned.slice(start, end + 1));
    throw new Error("返回内容不是合法 JSON");
  }
}
function matchHeaderRules(url, rules) {
  let host = "";
  try {
    host = new URL(url).host;
  } catch {
    return {};
  }
  const merged = {};
  for (const rule of rules) {
    const pattern = rule.host?.trim();
    if (!pattern) continue;
    const re = new RegExp(
      "^" + pattern.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*") + "$",
      "i"
    );
    if (re.test(host)) Object.assign(merged, rule.header ?? {});
  }
  return merged;
}
function parseRule(rule) {
  if (!rule) return [];
  return rule.split("||").map((s) => s.trim()).filter(Boolean).map((part) => {
    const segs = part.split("&&").map((s) => s.trim()).filter(Boolean);
    const selector = segs[0] ?? "";
    const args = [];
    for (const seg of segs.slice(1)) {
      for (const a of seg.split(",")) {
        const t = a.trim();
        if (t) args.push(t);
      }
    }
    return { selector, args };
  });
}
function ruleSelector(rule) {
  return parseRule(rule)[0]?.selector ?? "";
}
function absolutize(url, base) {
  const value = (url ?? "").trim();
  if (!value) return "";
  if (/^https?:\/\//i.test(value)) return value;
  if (/^data:/i.test(value)) return value;
  if (value.startsWith("//")) return `https:${value}`;
  try {
    return new URL(value, base).toString();
  } catch {
    return value;
  }
}
function readArg($, el, arg, base) {
  const key = arg.trim();
  const lower = key.toLowerCase();
  if (lower === "text" || lower === "textnodes") {
    return el.text().replace(/\s+/g, " ").trim();
  }
  if (lower === "html" || lower === "innerhtml") {
    return el.html()?.trim() ?? "";
  }
  if (lower === "outerhtml") {
    return $.html(el)?.trim() ?? "";
  }
  const raw = el.attr(key) ?? el.attr(lower) ?? "";
  const value = (raw ?? "").trim();
  if (!value) return "";
  if (lower === "href" || lower === "src" || lower.endsWith("src") || lower.endsWith("-url")) {
    return absolutize(value, base);
  }
  return value;
}
function extract($, el, rule, base, fallback = ["Text"]) {
  const parts = parseRule(rule);
  const branches = parts.length ? parts : [{ selector: "", args: fallback }];
  for (const part of branches) {
    const target = part.selector ? $(el).find(part.selector).first() : $(el);
    if (!target.length) continue;
    const args = part.args.length ? part.args : fallback;
    for (const arg of args) {
      const value = readArg($, target, arg, base);
      if (value) return value;
    }
  }
  return "";
}
function selectAll($, scope, rule) {
  const selector = ruleSelector(rule);
  if (!selector) return $(".__tvbox_none__");
  return scope.find(selector);
}
const memory = /* @__PURE__ */ new Map();
const dirty = /* @__PURE__ */ new Set();
const timers = /* @__PURE__ */ new Map();
const DEBOUNCE_MS = 200;
function fileOf(name) {
  return node_path.join(electron.app.getPath("userData"), `${name}.json`);
}
async function readStore(name, fallback) {
  if (memory.has(name)) return memory.get(name);
  try {
    const text = await node_fs.promises.readFile(fileOf(name), "utf-8");
    const data = JSON.parse(text);
    memory.set(name, data);
    return data;
  } catch {
    memory.set(name, fallback);
    return fallback;
  }
}
function writeStore(name, data) {
  memory.set(name, data);
  dirty.add(name);
  const old = timers.get(name);
  if (old) clearTimeout(old);
  timers.set(
    name,
    setTimeout(() => {
      void flushStore(name);
    }, DEBOUNCE_MS)
  );
}
async function flushStore(name) {
  const names = name ? [name] : [...dirty];
  await Promise.all(
    names.map(async (n) => {
      if (!dirty.has(n)) return;
      dirty.delete(n);
      const t = timers.get(n);
      if (t) {
        clearTimeout(t);
        timers.delete(n);
      }
      try {
        await node_fs.promises.mkdir(electron.app.getPath("userData"), { recursive: true });
        const tmp = `${fileOf(n)}.tmp`;
        await node_fs.promises.writeFile(tmp, JSON.stringify(memory.get(n), null, 2), "utf-8");
        await node_fs.promises.rename(tmp, fileOf(n));
      } catch (err) {
        console.error(`[store] 写入 ${n}.json 失败`, err);
      }
    })
  );
}
const NAME$2 = "settings";
const DEFAULT_SETTINGS = {
  concurrency: 8,
  timeout: 20,
  userAgent: DEFAULT_UA,
  accent: "#2563EB",
  density: "compact",
  sidebarCollapsed: false,
  // 采集站里「XX解说 / 一口气看完」这类二创短片和正片同名同封面，默认挡掉
  filterCommentary: true,
  externalPlayer: { command: "", args: ["{url}"], prefer: ["PotPlayer", "mpv", "VLC"] },
  window: { width: 1440, height: 900 },
  // API Key 默认留空：没填之前「AI 总结本集」按钮会提示去设置页填
  ai: { apiKey: "", model: "deepseek-flash", baseUrl: "" }
};
async function getSettings() {
  const stored = await readStore(NAME$2, {});
  return {
    ...DEFAULT_SETTINGS,
    ...stored,
    externalPlayer: { ...DEFAULT_SETTINGS.externalPlayer, ...stored.externalPlayer ?? {} },
    window: { ...DEFAULT_SETTINGS.window, ...stored.window ?? {} },
    ai: { ...DEFAULT_SETTINGS.ai, ...stored.ai ?? {} }
  };
}
async function saveSettings(patch) {
  const next = { ...await getSettings(), ...patch };
  writeStore(NAME$2, next);
  return next;
}
const STRING_TYPE_MAP = {
  cms: 3,
  maccms: 3,
  apple: 3,
  apples: 3,
  "苹果cms": 3,
  api: 4,
  json: 4,
  html: 1,
  web: 1,
  rule: 1,
  rules: 1,
  page: 1,
  spider: 0,
  jar: 0,
  aggregate: 0,
  other: 2
};
function shortHash(input) {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(36);
}
function normalizeApi(raw) {
  const api = (raw ?? "").trim();
  if (!api) return "";
  if (/^https?:\/\//i.test(api)) return api;
  if (/^(proxy|file|assets|clan|to)`?:\/\//i.test(api)) return api;
  if (/^[\w.-]+\.[a-z]{2,}/i.test(api)) return `https://${api}`;
  return api;
}
function normalizeType(raw, api, rules) {
  if (typeof raw === "number" && [0, 1, 2, 3, 4].includes(raw)) return raw;
  if (typeof raw === "string") {
    const key = raw.trim().toLowerCase();
    if (key) {
      const mapped = STRING_TYPE_MAP[key];
      if (mapped !== void 0) return mapped;
      const asNum = Number(key);
      if (Number.isInteger(asNum) && asNum >= 0 && asNum <= 4) return asNum;
      return 2;
    }
  }
  if (rules && (rules.list || rules.search)) return 1;
  if (/provide\/vod|api\.php|\/vod\//i.test(api)) return 3;
  if (api) return 4;
  return 2;
}
function flag(raw, fallback = false) {
  if (raw === void 0 || raw === null) return fallback;
  if (typeof raw === "boolean") return raw;
  const n = Number(raw);
  if (!Number.isNaN(n)) return n !== 0;
  const s = String(raw).toLowerCase();
  return s === "true" || s === "yes" || s === "1";
}
function normalizeRules(raw) {
  if (!raw || typeof raw !== "object") return void 0;
  const r = raw;
  const pick = (...keys) => {
    for (const k of keys) {
      const v = r[k];
      if (typeof v === "string" && v.trim()) return v.trim();
    }
    return void 0;
  };
  const rules = {
    list: pick("list", "vodList", "listRule"),
    name: pick("name", "vodName", "title"),
    link: pick("link", "vodLink", "href"),
    pic: pick("pic", "vodPic", "image"),
    remarks: pick("remarks", "vodRemarks", "note"),
    search: pick("search", "searchUrl"),
    detailName: pick("detailName"),
    detailContent: pick("detailContent", "content"),
    playList: pick("playList", "playFrom"),
    playItem: pick("playItem", "playUrl")
  };
  const cleaned = Object.fromEntries(
    Object.entries(rules).filter(([, v]) => typeof v === "string" && v)
  );
  return Object.keys(cleaned).length ? cleaned : void 0;
}
function normalizeSite(input, ctx) {
  if (!input || typeof input !== "object") return null;
  const raw = input;
  const name = String(raw.name ?? raw.title ?? "").trim();
  const api = normalizeApi(String(raw.api ?? raw.url ?? raw.ext?.api ?? ""));
  if (!name && !api) return null;
  const rules = normalizeRules(raw.rules ?? raw.ext?.rules);
  const type = normalizeType(raw.type, api, rules);
  const key = String(raw.key ?? raw.id ?? `csp_${shortHash(`${name}|${api}`)}`).trim();
  const site = {
    key,
    name: name || key,
    type,
    api,
    ext: typeof raw.ext === "string" ? raw.ext : raw.ext ? JSON.stringify(raw.ext) : void 0,
    jar: typeof raw.jar === "string" ? raw.jar : void 0,
    searchable: flag(raw.searchable, true),
    quickSearch: flag(raw.quickSearch, flag(raw.searchable, true)),
    filterable: flag(raw.filterable, type === 3 || type === 4),
    playerType: Number(raw.playerType ?? 1) || 1,
    categories: Array.isArray(raw.categories) ? raw.categories.map(String) : void 0,
    style: raw.style && typeof raw.style === "object" ? { type: raw.style.type, ratio: Number(raw.style.ratio) || void 0 } : void 0,
    header: {
      ...ctx.defaults?.header ?? {},
      ...raw.header && typeof raw.header === "object" ? raw.header : {}
    },
    timeout: Number(raw.timeout) || ctx.defaults?.timeout,
    sourceId: ctx.sourceId,
    sourceName: ctx.sourceName,
    enabled: flag(raw.enabled, true),
    rules
  };
  if (!Object.keys(site.header ?? {}).length) delete site.header;
  if (!site.api || /^(proxy|assets|file|clan|to):/i.test(site.api)) {
    site.unsupported = "该站点依赖内置 Spider 或本地资源，桌面端无法直接请求";
    site.searchable = false;
    site.quickSearch = false;
  } else if (type === 0) {
    site.unsupported = "需要配套 Spider（jar/dex），桌面端无法运行";
    site.searchable = false;
    site.quickSearch = false;
  } else if (type === 2) {
    site.unsupported = "未知站点类型，暂不支持";
    site.searchable = false;
    site.quickSearch = false;
  }
  return site;
}
function normalizeParses(raw) {
  if (!Array.isArray(raw)) return [];
  return raw.map((item) => {
    if (!item || typeof item !== "object") return null;
    const p = item;
    const url = String(p.url ?? "").trim();
    if (!url) return null;
    return {
      name: String(p.name ?? "未命名解析"),
      type: Number(p.type ?? 1) || 1,
      url,
      ext: p.ext
    };
  }).filter((x) => x !== null);
}
function normalizeLives(raw) {
  if (!Array.isArray(raw)) return [];
  const out = [];
  for (const item of raw) {
    if (typeof item === "string") {
      out.push({ name: "直播源", type: 0, url: item });
      continue;
    }
    if (!item || typeof item !== "object") continue;
    const l = item;
    const url = String(l.url ?? "").trim();
    if (!url || /^(proxy|assets|clan|file|to):/i.test(url)) continue;
    out.push({
      name: String(l.name ?? "直播源"),
      type: l.type ?? 0,
      url,
      epg: l.epg ? String(l.epg) : void 0
    });
  }
  return out;
}
function normalizeHeaderRules(raw) {
  if (!Array.isArray(raw)) return [];
  return raw.map((item) => {
    if (!item || typeof item !== "object") return null;
    const h = item;
    if (!h.host || !h.header) return null;
    return { host: String(h.host), header: h.header };
  }).filter((x) => x !== null);
}
function parseConfig(rawInput, ctx) {
  const raw = rawInput ?? {};
  const ext = raw.tvboxDesktop ?? {};
  const settings = raw.settings ?? {};
  const defaults = {
    timeout: Number(ext.timeout ?? settings.timeout ?? ctx.defaults?.timeout) || void 0,
    header: {
      ...ctx.defaults?.header ?? {},
      ...raw.header && typeof raw.header === "object" ? raw.header : {}
    }
  };
  const sitesRaw = Array.isArray(raw.sites) ? raw.sites : [];
  const seen = /* @__PURE__ */ new Set();
  const sites = [];
  for (const item of sitesRaw) {
    const site = normalizeSite(item, { ...ctx, defaults });
    if (!site) continue;
    if (seen.has(site.key)) continue;
    seen.add(site.key);
    sites.push(site);
  }
  return {
    name: String(raw.name ?? ext.name ?? ctx.sourceName ?? "未命名配置"),
    notice: raw.notice ? String(raw.notice) : void 0,
    sites,
    parses: normalizeParses(raw.parses),
    lives: normalizeLives(raw.lives),
    flags: Array.isArray(raw.flags) ? raw.flags.map(String) : [],
    headers: normalizeHeaderRules(raw.headers ?? settings.headers),
    theme: raw.theme ?? ext.theme,
    externalPlayer: raw.externalPlayer ?? ext.externalPlayer,
    home: raw.home ?? ext.home,
    raw: rawInput
  };
}
async function loadConfigSource(source, timeout = 20) {
  let json;
  if (source.kind === "file") {
    const text = await node_fs.promises.readFile(source.url, "utf-8");
    json = JSON.parse(text.replace(/^\uFEFF/, ""));
  } else {
    json = await fetchJson(source.url, { timeout });
  }
  return parseConfig(json, { sourceId: source.id, sourceName: source.name, defaults: { timeout } });
}
const NAME$1 = "sources";
const parsedCache = /* @__PURE__ */ new Map();
let hydrated = false;
async function listSources() {
  const list = await readStore(NAME$1, []);
  return Array.isArray(list) ? list : [];
}
async function saveSources(list) {
  writeStore(NAME$1, list);
}
async function hydrate() {
  if (hydrated) return;
  hydrated = true;
  const list = await listSources();
  for (const source of list) {
    if (!source.enabled || !source.raw) continue;
    try {
      parsedCache.set(
        source.id,
        parseConfig(source.raw, { sourceId: source.id, sourceName: source.name })
      );
    } catch (err) {
      console.warn(`[sources] 回填 ${source.name} 失败`, err);
    }
  }
}
function getParsed(sourceId) {
  return parsedCache.get(sourceId);
}
async function addSource(input) {
  const url = input.url.trim();
  if (!url) throw new Error("地址不能为空");
  const kind = input.kind ?? (/^https?:\/\//i.test(url) ? "url" : "file");
  const list = await listSources();
  if (list.some((s) => s.url === url)) throw new Error("该配置源已存在");
  const source = {
    id: node_crypto.randomUUID(),
    name: (input.name || "").trim() || guessName(url, kind),
    url,
    kind,
    enabled: true,
    lastSync: 0,
    siteCount: 0,
    liveCount: 0,
    parseCount: 0
  };
  list.push(source);
  await saveSources(list);
  return source;
}
function guessName(url, kind) {
  if (kind === "file") {
    const base = url.split(/[\\/]/).pop() ?? "本地配置";
    return base.replace(/\.json$/i, "");
  }
  try {
    return new URL(url).hostname;
  } catch {
    return "远程配置";
  }
}
async function updateSource(id, patch) {
  const list = await listSources();
  const idx = list.findIndex((s) => s.id === id);
  if (idx < 0) throw new Error("配置源不存在");
  const next = { ...list[idx], ...patch };
  if (patch.url) next.kind = /^https?:\/\//i.test(patch.url) ? "url" : "file";
  list[idx] = next;
  await saveSources(list);
  if (patch.enabled === false) parsedCache.delete(id);
  return next;
}
async function removeSource(id) {
  const list = await listSources();
  await saveSources(list.filter((s) => s.id !== id));
  parsedCache.delete(id);
}
async function syncSource(id) {
  const list = await listSources();
  const idx = list.findIndex((s) => s.id === id);
  if (idx < 0) throw new Error("配置源不存在");
  const source = list[idx];
  const settings = await getSettings();
  const next = { ...source };
  try {
    const parsed = await loadConfigSource(source, settings.timeout);
    parsedCache.set(source.id, parsed);
    next.raw = parsed.raw;
    next.lastSync = Date.now();
    next.error = void 0;
    next.name = source.name || parsed.name;
    next.notice = parsed.notice;
    next.siteCount = parsed.sites.length;
    next.liveCount = parsed.lives.length;
    next.parseCount = parsed.parses.length;
  } catch (err) {
    next.error = err.message;
  }
  list[idx] = next;
  await saveSources(list);
  return next;
}
async function syncAll(onlyEnabled = true) {
  const list = await listSources();
  const targets = list.filter((s) => onlyEnabled ? s.enabled : true);
  const results = [];
  for (const source of targets) {
    results.push(await syncSource(source.id));
  }
  return results;
}
const NAME = "sites";
async function readOverrides() {
  const data = await readStore(NAME, {});
  return data && typeof data === "object" ? data : {};
}
async function writeOverrides(map) {
  writeStore(NAME, map);
}
async function getSites() {
  const sources = await listSources();
  const overrides = await readOverrides();
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const source of sources) {
    if (!source.enabled) continue;
    const parsed = getParsed(source.id);
    if (!parsed) continue;
    for (const site of parsed.sites) {
      if (seen.has(site.key)) continue;
      seen.add(site.key);
      const ov = overrides[site.key];
      const merged = { ...site };
      if (ov) {
        if (ov.enabled !== void 0) merged.enabled = ov.enabled;
        if (ov.name) merged.name = ov.name;
        if (ov.timeout) merged.timeout = ov.timeout;
        if (ov.header) merged.header = { ...merged.header, ...ov.header };
        if (ov.health !== void 0) merged.health = ov.health;
      }
      out.push(merged);
    }
  }
  out.sort((a, b) => {
    const oa = overrides[a.key]?.order ?? Number.MAX_SAFE_INTEGER;
    const ob = overrides[b.key]?.order ?? Number.MAX_SAFE_INTEGER;
    if (oa !== ob) return oa - ob;
    return a.name.localeCompare(b.name, "zh-Hans-CN");
  });
  return out;
}
async function getSite(key) {
  return (await getSites()).find((s) => s.key === key);
}
async function setSiteEnabled(key, enabled) {
  const map = await readOverrides();
  map[key] = { ...map[key] ?? {}, enabled };
  await writeOverrides(map);
}
async function setSitesEnabled(keys, enabled) {
  const map = await readOverrides();
  for (const key of keys) map[key] = { ...map[key] ?? {}, enabled };
  await writeOverrides(map);
}
async function resolveHeader(site, url) {
  const sources = await listSources();
  const rules = sources.filter((s) => s.enabled).flatMap((s) => getParsed(s.id)?.headers ?? []);
  const settings = await getSettings();
  return {
    "User-Agent": settings.userAgent,
    ...matchHeaderRules(url, rules),
    ...site.header ?? {}
  };
}
async function testSite(key) {
  const site = await getSite(key);
  if (!site) return { ok: false, ms: 0, message: "站点不存在" };
  if (site.unsupported) return { ok: false, ms: 0, message: site.unsupported };
  if (!site.api) return { ok: false, ms: 0, message: "站点未配置接口地址" };
  const settings = await getSettings();
  const timeout = site.timeout ?? settings.timeout;
  const start = Date.now();
  try {
    if (site.type === 3 || site.type === 4) {
      const url = buildCmsUrl(site, { ac: "detail", pg: 1 });
      const header = await resolveHeader(site, url);
      const text = await fetchText(url, { header, timeout });
      const payload = JSON.parse(text.replace(/^\uFEFF/, "").trim());
      if (!isCmsOk(payload)) {
        return { ok: false, ms: Date.now() - start, message: `接口返回异常：${payload.msg ?? "code 非成功"}` };
      }
      const list = payload.list;
      const count = Array.isArray(list) ? list.length : 0;
      if (!count) return { ok: false, ms: Date.now() - start, message: "接口连通但未返回数据" };
      const sample = String(list[0]?.vod_name ?? "");
      await saveHealth(key, Date.now() - start);
      return { ok: true, ms: Date.now() - start, message: `正常，返回 ${count} 条`, sample };
    }
    if (site.type === 1) {
      const selector = site.rules?.list?.trim();
      const template = (site.rules?.search || site.api).trim();
      const target = template.replace(/\{(wd|kw|key|keyword)\}/gi, encodeURIComponent("测试"));
      if (!/^https?:\/\//i.test(target)) {
        return { ok: false, ms: 0, message: "网页规则站需要一个 http(s) 地址，当前地址不可请求" };
      }
      const header = await resolveHeader(site, target);
      const text = await fetchText(target, { header, timeout });
      const len = text.length;
      if (len < 50) return { ok: false, ms: Date.now() - start, message: "页面内容过短，可能被拦截" };
      if (selector) {
        const count = cheerio__namespace.load(text)(selector).length;
        if (!count) {
          return {
            ok: false,
            ms: Date.now() - start,
            message: `页面可访问，但列表选择器「${selector}」没有匹配到节点，规则可能已失效`
          };
        }
        await saveHealth(key, Date.now() - start);
        return { ok: true, ms: Date.now() - start, message: `正常，匹配到 ${count} 个列表节点` };
      }
      await saveHealth(key, Date.now() - start);
      return { ok: true, ms: Date.now() - start, message: `正常，页面 ${len} 字节` };
    }
    return { ok: false, ms: 0, message: site.unsupported ?? "该类型暂不支持测试" };
  } catch (err) {
    await saveHealth(key, -1);
    return { ok: false, ms: Date.now() - start, message: err.message };
  }
}
async function saveHealth(key, ms) {
  const map = await readOverrides();
  map[key] = { ...map[key] ?? {}, health: ms };
  await writeOverrides(map);
}
const DEFAULT_LIMIT = 30;
let currentToken = 0;
function cancelSearch() {
  currentToken++;
}
function fail$1(site, message, ms = 0) {
  return { siteKey: site.key, siteName: site.name, ok: false, ms, message, list: [] };
}
function cmsItemToVod(raw, site) {
  const s = (v) => v === void 0 || v === null ? "" : String(v).trim();
  return {
    vod_id: s(raw.vod_id ?? raw.id),
    vod_name: s(raw.vod_name ?? raw.name),
    vod_pic: absolutize(s(raw.vod_pic ?? raw.pic), site.api),
    vod_remarks: s(raw.vod_remarks ?? raw.remarks),
    vod_year: s(raw.vod_year ?? raw.year),
    vod_area: s(raw.vod_area ?? raw.area),
    vod_actor: s(raw.vod_actor ?? raw.actor),
    vod_director: s(raw.vod_director ?? raw.director),
    type_name: s(raw.type_name ?? raw.class),
    vod_score: s(raw.vod_score ?? raw.score),
    siteKey: site.key,
    siteName: site.name,
    sourceId: site.sourceId
  };
}
async function searchCms(site, wd, limit, timeout) {
  const ac = /\{ac\}/i.test(site.api) ? "videolist" : "detail";
  const url = buildCmsUrl(site, { ac, wd, pg: 1 });
  const header = await resolveHeader(site, url);
  const text = await fetchText(url, { header, timeout });
  const payload = parseLooseJson(text);
  if (!isCmsOk(payload)) {
    throw new Error(`接口返回异常：${String(payload?.msg ?? "code 非成功")}`);
  }
  return asArray(payload.list).slice(0, limit).map((item) => cmsItemToVod(item, site)).filter((v) => v.vod_name && v.vod_id);
}
async function searchHtml(site, wd, limit, timeout) {
  const template = (site.rules?.search || site.api).trim();
  const target = template.replace(/\{(wd|kw|key|keyword)\}/gi, encodeURIComponent(wd));
  if (!/^https?:\/\//i.test(target)) {
    throw new Error("网页规则站缺少可请求的搜索地址");
  }
  const header = await resolveHeader(site, target);
  const text = await fetchText(target, { header, timeout });
  const $ = cheerio__namespace.load(text);
  const rules = site.rules ?? {};
  const nodes = $((rules.list || "").trim());
  if (!nodes.length) throw new Error("列表选择器没有匹配到节点，规则可能已失效");
  const out = [];
  nodes.slice(0, limit).each((_i, el) => {
    const node = $(el);
    const link = extract($, node, rules.link, target, ["href", "Text"]);
    const name = extract($, node, rules.name, target, ["Text"]);
    if (!name) return;
    out.push({
      // 网页规则站没有稳定的数字 id，直接把详情页地址当作 id。
      // 这样详情页不需要再猜一次地址，也不会因为站点改版而失效。
      vod_id: link || name,
      vod_name: name,
      vod_pic: extract($, node, rules.pic, target, ["data-src", "data-original", "src"]),
      vod_remarks: extract($, node, rules.remarks, target, ["Text"]),
      vod_year: "",
      vod_area: "",
      vod_actor: "",
      vod_director: "",
      type_name: "",
      vod_score: "",
      siteKey: site.key,
      siteName: site.name,
      sourceId: site.sourceId
    });
  });
  return out;
}
async function searchSite(site, wd, limit = DEFAULT_LIMIT) {
  const start = Date.now();
  if (site.unsupported) return fail$1(site, site.unsupported);
  if (!site.searchable) return fail$1(site, "该站点已关闭搜索");
  if (!site.api) return fail$1(site, "站点未配置接口地址");
  try {
    const timeout = site.timeout ?? (await getSettings()).timeout;
    let list;
    if (site.type === 3 || site.type === 4) {
      list = await searchCms(site, wd, limit, timeout);
    } else if (site.type === 1) {
      list = await searchHtml(site, wd, limit, timeout);
    } else {
      return fail$1(site, site.unsupported ?? "该类型暂不支持搜索");
    }
    const ms = Date.now() - start;
    return {
      siteKey: site.key,
      siteName: site.name,
      ok: true,
      ms,
      message: list.length ? `找到 ${list.length} 条` : "没有匹配结果",
      list
    };
  } catch (err) {
    return fail$1(site, err.message, Date.now() - start);
  }
}
async function searchableSites() {
  const sites = await getSites();
  return sites.filter((s) => s.enabled && s.searchable && !s.unsupported);
}
async function searchAll(wd, options = {}, onResult, onStart) {
  const keyword = (wd ?? "").trim();
  const started = Date.now();
  if (!keyword) return { wd: keyword, ms: 0, total: 0, results: [] };
  const token = ++currentToken;
  const all = await searchableSites();
  const targets = options.sites?.length ? all.filter((s) => options.sites?.includes(s.key)) : all;
  if (!targets.length) return { wd: keyword, ms: 0, total: 0, results: [] };
  const settings = await getSettings();
  const concurrency = Math.max(
    1,
    Math.min(32, options.concurrency ?? settings.concurrency ?? 8)
  );
  const limit = options.limitPerSite ?? DEFAULT_LIMIT;
  const results = [];
  let cursor = 0;
  let done = 0;
  const worker = async () => {
    for (; ; ) {
      if (token !== currentToken) return;
      const index = cursor++;
      if (index >= targets.length) return;
      const result = await searchSite(targets[index], keyword, limit);
      if (token !== currentToken) return;
      results.push(result);
      done++;
      onResult?.(result, done, targets.length);
    }
  };
  await Promise.all(
    Array.from({ length: Math.min(concurrency, targets.length) }, () => worker())
  );
  return { wd: keyword, ms: Date.now() - started, total: targets.length, results };
}
function parseLines(from, url, note = "") {
  const froms = (from ?? "").split("$$$");
  const groups = (url ?? "").split("$$$");
  const notes = (note ?? "").split("$$$");
  const lines = [];
  groups.forEach((group, gi) => {
    const name = (froms[gi] || notes[gi] || `线路${gi + 1}`).trim();
    const episodes = [];
    for (const segment of group.split("#")) {
      const seg = segment.trim();
      if (!seg) continue;
      const split = seg.indexOf("$");
      const epName = split >= 0 ? seg.slice(0, split).trim() : "";
      const epUrl = split >= 0 ? seg.slice(split + 1).trim() : seg;
      if (!epUrl) continue;
      episodes.push({
        name: epName || `第${episodes.length + 1}集`,
        url: epUrl,
        index: episodes.length
      });
    }
    if (episodes.length) lines.push({ name, episodes });
  });
  return lines;
}
async function detailCms(site, vodId) {
  const timeout = site.timeout ?? (await getSettings()).timeout;
  const url = buildCmsUrl(site, { ac: "detail", ids: vodId });
  const header = await resolveHeader(site, url);
  const text = await fetchText(url, { header, timeout });
  const payload = parseLooseJson(text);
  if (!isCmsOk(payload)) {
    throw new Error(`接口返回异常：${String(payload?.msg ?? "code 非成功")}`);
  }
  const raw = asArray(payload.list)[0];
  if (!raw) throw new Error("接口没有返回该影片的详情");
  const base = cmsItemToVod(raw, site);
  const s = (v) => v === void 0 || v === null ? "" : String(v);
  return {
    ...base,
    vod_content: s(raw.vod_content ?? raw.vod_blurb ?? "").replace(/<[^>]+>/g, "").trim(),
    lines: parseLines(s(raw.vod_play_from), s(raw.vod_play_url), s(raw.vod_play_note))
  };
}
async function detailHtml(site, vodId) {
  if (!/^https?:\/\//i.test(vodId)) {
    throw new Error("该网页规则站没有解析出可用的详情页地址");
  }
  const timeout = site.timeout ?? (await getSettings()).timeout;
  const header = await resolveHeader(site, vodId);
  const text = await fetchText(vodId, { header, timeout });
  const $ = cheerio__namespace.load(text);
  const rules = site.rules ?? {};
  const scope = $("body").length ? $("body") : $.root();
  const name = extract($, scope, rules.detailName, vodId, ["Text"]) || $("h1").first().text().trim() || $("title").first().text().trim();
  const content = extract($, scope, rules.detailContent, vodId, ["Text"]).replace(/\s+/g, " ").trim();
  const pic = extract($, scope, rules.pic, vodId, ["data-src", "data-original", "src"]);
  const lines = [];
  const containers = selectAll($, scope, rules.playList);
  if (containers.length && rules.playItem) {
    containers.each((i, el) => {
      const node = $(el);
      const episodes = [];
      selectAll($, node, rules.playItem).each((_j, a) => {
        const anchor = $(a);
        const url = (anchor.attr("href") ?? "").trim();
        const label = anchor.text().replace(/\s+/g, " ").trim();
        if (!url) return;
        episodes.push({
          name: label || `第${episodes.length + 1}集`,
          url,
          index: episodes.length
        });
      });
      if (episodes.length) {
        const label = (node.attr("data-name") ?? "").trim() || node.find("h3,h2,.title,.name").first().text().trim() || `线路${i + 1}`;
        lines.push({ name: label, episodes });
      }
    });
  }
  if (!lines.length && rules.playItem) {
    const episodes = [];
    selectAll($, scope, rules.playItem).each((_j, a) => {
      const anchor = $(a);
      const url = (anchor.attr("href") ?? "").trim();
      const label = anchor.text().replace(/\s+/g, " ").trim();
      if (!url) return;
      episodes.push({ name: label || `第${episodes.length + 1}集`, url, index: episodes.length });
    });
    if (episodes.length) lines.push({ name: "默认线路", episodes });
  }
  if (!name && !lines.length) {
    throw new Error("详情页没有解析出内容，规则可能已失效");
  }
  const placeholder = {
    vod_id: vodId,
    vod_name: name || vodId,
    vod_pic: pic,
    vod_remarks: "",
    vod_year: "",
    vod_area: "",
    vod_actor: "",
    vod_director: "",
    type_name: "",
    vod_score: "",
    siteKey: site.key,
    siteName: site.name,
    sourceId: site.sourceId
  };
  return { ...placeholder, vod_content: content, lines };
}
async function getVodDetail(siteKey, vodId) {
  const site = await getSite(siteKey);
  if (!site) throw new Error("站点不存在或已被禁用");
  if (site.unsupported) throw new Error(site.unsupported);
  if (!vodId) throw new Error("缺少影片 id");
  if (site.type === 3 || site.type === 4) return detailCms(site, vodId);
  if (site.type === 1) return detailHtml(site, vodId);
  throw new Error(site.unsupported ?? "该类型暂不支持获取详情");
}
const OFFICIAL_BASE = "https://api.deepseek.com";
const DEFAULT_MODEL = "deepseek-flash";
const TIMEOUT$1 = 9e4;
const VISUAL_TIMEOUT = 12e4;
const MAX_FRAMES = 140;
const SYSTEM_TEXT = [
  "你是一个中文影视剧剧情助手。用户会给你一部剧（或番剧、综艺、动漫）的资料，以及他当前正在看的集数。",
  "请针对「这一集」输出内容，不要复述整部剧的简介。",
  "",
  "输出格式（纯文本，不要用 Markdown 标题符号）：",
  "第一段：用 2 到 4 句话说清这一集讲了什么。",
  "然后另起一行写「本集看点」，下面用「- 」列 3 到 5 条。",
  "",
  "硬性要求：",
  "1. 如果资料不足以确定这一集的具体情节，就在第一段里如实说明「仅凭现有资料无法确定这一集的具体情节」，然后只写你能推断的内容，绝对不要编造具体的人物、台词或事件。",
  "2. 不要写「好的」「以下是」这类客套话。",
  "3. 不要重复用户给你的原始资料。",
  "4. 全文控制在 400 字以内，用简体中文。"
].join("\n");
const SYSTEM_VISUAL = [
  "你是一个中文影视剧剧情解说。用户会给你一部剧集的资料，以及**按时间顺序从这一集里抽出来的画面**——每张图前面标着它在片中的时间点。",
  "你要根据这些画面写出这一集实际发生了什么，而不是根据剧名去猜。",
  "",
  "输出格式（纯文本，不要用 Markdown 标题符号）：",
  "第一段：用 3 到 6 句话说清这一集的剧情走向，按时间顺序。",
  "然后另起一行写「剧情节点」，下面用「- [时间] 内容」的形式列 4 到 8 条关键节点。把相邻的画面合并成一条，不要一帧一条。",
  "然后另起一行写「本集看点」，下面用「- 」列 2 到 4 条。",
  "",
  "硬性要求：",
  "1. 这些画面是每 20 秒抽一帧得到的，而且**没有声音**。所以：画面上出现字幕或文字时可以照实引用；但**不要编造对白、人物姓名，或画面上根本看不到的情节**；只描述你确实从画面里看到的东西，拿不准的地方就明说看不出来。",
  "2. 如果画面几乎全是片头、黑屏、静态图或者内容高度重复，就在第一段里直接说明「这一集抽到的画面信息量很少」，不要硬编。",
  "3. 不要写「好的」「以下是」这类客套话，不要重复用户给你的资料。",
  "4. 全文控制在 600 字以内，用简体中文。"
].join("\n");
function nonEmpty(label, value) {
  const text = (value ?? "").trim();
  return text ? `${label}：${text}` : "";
}
function buildUser(input) {
  const meta = [
    nonEmpty("片名", input.vodName),
    nonEmpty("类型", input.typeName),
    nonEmpty("年份", input.year),
    nonEmpty("地区", input.area),
    nonEmpty("导演", input.director),
    nonEmpty("演员", input.actor),
    nonEmpty("评分", input.score),
    nonEmpty("备注", input.remarks)
  ].filter(Boolean);
  const total = input.epTotal > 0 ? input.epTotal : "?";
  const line = input.lineName ? `，线路「${input.lineName}」` : "";
  const episode = `当前正在看：${input.epName}（第 ${input.epIndex + 1} 集 / 共 ${total} 集${line}）`;
  const intro = (input.content ?? "").trim();
  return [
    "【影片资料】",
    meta.join("\n"),
    "",
    episode,
    intro ? `
【整部剧的简介】
${intro.slice(0, 1200)}` : ""
  ].filter((part) => part !== "").join("\n");
}
function stamp(seconds) {
  const s = Math.max(0, Math.round(seconds));
  const m = Math.floor(s / 60);
  return `${String(m).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}
function buildVisualUser(input, frames) {
  const blocks = [
    { type: "text", text: buildUser(input) },
    {
      type: "text",
      text: `
【按时间顺序抽取的画面】共 ${frames.length} 帧，每帧前标着它在片中的时间点。`
    }
  ];
  for (const frame of frames) {
    blocks.push({ type: "text", text: `[${stamp(frame.t)}]` });
    blocks.push({
      type: "image_url",
      // detail:'low' 会先缩到 512×512 再推理，省钱也更快；这些图本来就只有 512 宽
      image_url: { url: `data:image/jpeg;base64,${frame.b64}`, detail: "low" }
    });
  }
  return blocks;
}
function explainStatus(status, detail) {
  if (status === 401) return "DeepSeek 说这个 API Key 不对（401）。去「设置 → AI 总结」里检查一下。";
  if (status === 402) return "DeepSeek 账户余额不足（402），去 platform.deepseek.com 充值后再试。";
  if (status === 404) return `模型名可能不对（404）。${detail}`;
  if (status === 413) return "这次传的画面太多了，接口拒收（413）。把「抽帧间隔」调大一点再试。";
  if (status === 429) return "请求太频繁被限流了（429），等一会儿再试。";
  if (status >= 500) return `DeepSeek 服务端出错（HTTP ${status}），稍后再试。`;
  return `DeepSeek 返回了 HTTP ${status}。${detail}`;
}
async function loadConfig() {
  const settings = await getSettings();
  const apiKey = (settings.ai?.apiKey ?? "").trim();
  if (!apiKey) {
    throw new Error("还没有配置 DeepSeek API Key。去「设置 → AI 总结」里填一下就能用了。");
  }
  const model = (settings.ai?.model ?? "").trim() || DEFAULT_MODEL;
  const base = ((settings.ai?.baseUrl ?? "").trim() || OFFICIAL_BASE).replace(/\/+$/, "");
  return { apiKey, model, base, url: `${base}/chat/completions` };
}
async function callDeepSeek(cfg, opts) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), opts.timeout);
  const startedAt = Date.now();
  let res;
  try {
    res = await fetch(cfg.url, {
      method: "POST",
      signal: controller.signal,
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${cfg.apiKey}`
      },
      body: JSON.stringify({
        model: cfg.model,
        messages: [
          { role: "system", content: opts.system },
          { role: "user", content: opts.user }
        ],
        // 写摘要不需要思维链：关掉它，快很多也便宜很多
        thinking: { type: "disabled" },
        max_tokens: opts.maxTokens,
        stream: false
      })
    });
  } catch (err) {
    const e = err;
    if (e.name === "AbortError") {
      throw new Error(
        `等 DeepSeek 回复超过 ${Math.round(opts.timeout / 1e3)} 秒，先不等了。可以再点一次重试。`
      );
    }
    throw new Error(`连不上 ${cfg.base}：${e.message}。检查网络，或者系统代理是不是开着但没跑起来。`);
  } finally {
    clearTimeout(timer);
  }
  const raw = await res.text();
  let json = {};
  try {
    json = JSON.parse(raw);
  } catch {
  }
  if (!res.ok) {
    const detail = (json.error?.message ?? raw.slice(0, 200)).trim();
    throw new Error(explainStatus(res.status, detail));
  }
  const text = json.choices?.[0]?.message?.content?.trim() ?? "";
  if (!text) {
    throw new Error("DeepSeek 这次没返回任何内容，再点一次试试。");
  }
  return {
    text,
    model: cfg.model,
    ms: Date.now() - startedAt,
    usage: json.usage ? {
      prompt: json.usage.prompt_tokens ?? 0,
      completion: json.usage.completion_tokens ?? 0,
      total: json.usage.total_tokens ?? 0
    } : void 0
  };
}
async function summarizeEpisode(input) {
  const cfg = await loadConfig();
  return callDeepSeek(cfg, {
    system: SYSTEM_TEXT,
    user: buildUser(input),
    maxTokens: 900,
    timeout: TIMEOUT$1
  });
}
async function summarizeEpisodeVisual(input, frames) {
  const usable = frames.filter((f) => typeof f?.b64 === "string" && f.b64.length > 64).slice(0, MAX_FRAMES);
  if (!usable.length) return summarizeEpisode(input);
  const cfg = await loadConfig();
  return callDeepSeek(cfg, {
    system: SYSTEM_VISUAL,
    user: buildVisualUser(input, usable),
    maxTokens: 1600,
    // 帧多了以后上传 + 推理都慢，按帧数把超时放宽
    timeout: Math.min(VISUAL_TIMEOUT + usable.length * 1e3, 3e5)
  });
}
const SKIP = /(解说|演员|明星|资讯|新闻|预告|花絮|伦理|福利|写真|片花|榜单)/;
const BUCKETS = [
  { name: "电影", re: /电影|影院/ },
  { name: "短剧", re: /短剧|微剧|竖屏/ },
  { name: "纪录片", re: /纪录|记录|纪实/ },
  { name: "动漫", re: /动漫|动画|番剧|漫画|漫剧/ },
  { name: "综艺", re: /综艺|真人秀|脱口秀/ },
  { name: "体育", re: /体育|赛事|足球|篮球|台球/ },
  { name: "少儿", re: /少儿|儿童|亲子|幼教|益智/ },
  { name: "电视剧", re: /电视剧|连续剧|电视|剧集|国产剧|美剧|韩剧|日剧|港剧|台剧|泰剧/ }
];
const ORDER = ["电影", "电视剧", "动漫", "综艺", "纪录片", "短剧", "体育", "少儿"];
const LEAF_FOLLOWS_PARENT = [
  { leaf: /^动画片$/, parent: /电影/, bucket: "电影" }
];
const SUBS = {
  电影: [
    { name: "动作", re: /动作/ },
    { name: "喜剧", re: /喜剧/ },
    { name: "爱情", re: /爱情/ },
    { name: "科幻", re: /科幻/ },
    { name: "恐怖", re: /恐怖|惊悚/ },
    { name: "剧情", re: /剧情/ },
    { name: "战争", re: /战争/ },
    { name: "动画", re: /动画|动漫/ }
  ],
  电视剧: [
    { name: "国产", re: /国产|大陆/ },
    { name: "香港", re: /香港|港澳|港剧/ },
    { name: "台湾", re: /台湾|台剧/ },
    { name: "韩国", re: /韩国|韩剧/ },
    { name: "日本", re: /日本|日剧/ },
    { name: "欧美", re: /欧美|美剧/ },
    { name: "泰国", re: /泰国|泰剧/ },
    { name: "海外", re: /海外|其他/ }
  ],
  动漫: [
    { name: "国产", re: /国产|中国/ },
    { name: "日本", re: /日本|日韩/ },
    { name: "欧美", re: /欧美/ },
    { name: "港台", re: /港台/ },
    { name: "海外", re: /海外/ },
    { name: "动画电影", re: /电影/ },
    { name: "动画片", re: /动画片/ }
  ],
  综艺: [
    { name: "大陆", re: /大陆|国产/ },
    { name: "港台", re: /港台/ },
    { name: "日韩", re: /日韩/ },
    { name: "欧美", re: /欧美/ }
  ],
  体育: [
    { name: "足球", re: /足球/ },
    { name: "篮球", re: /篮球/ },
    { name: "网球", re: /网球/ },
    { name: "台球", re: /台球|斯诺克/ },
    { name: "其他", re: /其他|综合/ }
  ],
  短剧: [
    { name: "擦边短剧", re: /擦边/ },
    { name: "古装仙侠", re: /古装|仙侠/ },
    { name: "现代都市", re: /现代|都市/ },
    { name: "穿越年代", re: /穿越|年代/ },
    { name: "言情总裁", re: /言情|总裁/ },
    { name: "重生民国", re: /重生|民国/ },
    { name: "反转爽剧", re: /反转|爽剧/ },
    { name: "脑洞悬疑", re: /脑洞|悬疑/ },
    { name: "短剧", re: /短剧|微剧|竖屏/ }
  ],
  纪录片: [{ name: "纪录片", re: /纪录|记录|纪实/ }]
};
const CLASS_TTL = 10 * 60 * 1e3;
const classCache = /* @__PURE__ */ new Map();
const inflight = /* @__PURE__ */ new Map();
let categoryGeneration = 0;
function clearCategoryCache() {
  classCache.clear();
  inflight.clear();
  categoryGeneration++;
}
function str(value) {
  return value === void 0 || value === null ? "" : String(value).trim();
}
function normalizeClasses(raw) {
  return asArray(raw).map((item) => ({
    id: str(item.type_id ?? item.id ?? item.tid),
    name: str(item.type_name ?? item.name ?? item.title),
    pid: str(item.type_pid ?? item.pid ?? "0") || "0"
  })).filter((c) => c.id && c.name);
}
function leafIds(classes, rootId) {
  const children = classes.filter((c) => c.pid === rootId);
  if (!children.length) return [rootId];
  return children.flatMap((c) => leafIds(classes, c.id));
}
function bucketOf(name) {
  if (!name || SKIP.test(name)) return null;
  for (const { name: bucket, re } of BUCKETS) if (re.test(name)) return bucket;
  return null;
}
function subOf(bucket, leafName) {
  for (const { name, re } of SUBS[bucket] ?? []) if (re.test(leafName)) return name;
  return leafName;
}
function ancestry(leaf, byId) {
  const chain = [];
  let cur = leaf;
  for (let depth = 0; cur && depth < 8; depth++) {
    chain.push(cur);
    if (cur.pid === "0") break;
    cur = byId.get(cur.pid);
  }
  return chain;
}
function collectLeaves(classes) {
  const byId = new Map(classes.map((c) => [c.id, c]));
  const parents = new Set(classes.filter((c) => c.pid !== "0").map((c) => c.pid));
  const leaves = [];
  for (const leaf of classes) {
    if (parents.has(leaf.id)) continue;
    const chain = ancestry(leaf, byId);
    if (chain.some((c) => SKIP.test(c.name))) continue;
    let bucket = chain.map((c) => bucketOf(c.name)).find((b) => Boolean(b));
    const follow = LEAF_FOLLOWS_PARENT.find(
      (r) => r.leaf.test(leaf.name) && chain.some((c) => r.parent.test(c.name))
    );
    if (follow) bucket = follow.bucket;
    if (!bucket) continue;
    const sub = subOf(bucket, leaf.name);
    const rules = SUBS[bucket] ?? [];
    const at = rules.findIndex((r) => r.name === sub);
    leaves.push({ id: leaf.id, bucket, sub, order: at < 0 ? rules.length : at });
  }
  return leaves;
}
async function loadClasses(site) {
  const cached = classCache.get(site.key);
  if (cached && Date.now() - cached.at < CLASS_TTL) return cached.classes;
  const pending = inflight.get(site.key);
  if (pending) return pending;
  const gen = categoryGeneration;
  const task = (async () => {
    try {
      const url = buildCmsUrl(site, { ac: "list" });
      const text = await fetchText(url, { header: await resolveHeader(site, url) });
      const payload = parseLooseJson(text);
      if (!isCmsOk(payload)) return [];
      const classes = normalizeClasses(payload.class);
      if (gen === categoryGeneration) classCache.set(site.key, { at: Date.now(), classes });
      return classes;
    } catch {
      return [];
    } finally {
      inflight.delete(site.key);
    }
  })();
  inflight.set(site.key, task);
  return task;
}
async function listCategories() {
  const sites = (await getSites()).filter((s) => s.enabled && (s.type === 3 || s.type === 4));
  const trees = await Promise.all(
    sites.map(async (site) => ({ site, classes: await loadClasses(site) }))
  );
  const grouped = /* @__PURE__ */ new Map();
  for (const { site, classes } of trees) {
    for (const leaf of collectLeaves(classes)) {
      const subs = grouped.get(leaf.bucket) ?? /* @__PURE__ */ new Map();
      grouped.set(leaf.bucket, subs);
      const sitesOfSub = subs.get(leaf.sub) ?? /* @__PURE__ */ new Map();
      subs.set(leaf.sub, sitesOfSub);
      const entry = sitesOfSub.get(site.key) ?? { name: site.name, ids: /* @__PURE__ */ new Set(), order: leaf.order };
      for (const id of leafIds(classes, leaf.id)) entry.ids.add(id);
      sitesOfSub.set(site.key, entry);
    }
  }
  const buckets = [];
  for (const [bucket, subs] of grouped) {
    const list = [];
    for (const [name, sitesOfSub] of subs) {
      const sitesOf = [...sitesOfSub.entries()].filter(([, v]) => v.ids.size).map(([siteKey, v]) => ({ siteKey, siteName: v.name, typeIds: [...v.ids] }));
      if (!sitesOf.length) continue;
      list.push({ name, sites: sitesOf, order: Math.min(...[...sitesOfSub.values()].map((v) => v.order)) });
    }
    list.sort((a, b) => a.order - b.order || a.name.localeCompare(b.name, "zh-CN"));
    if (list.length) buckets.push({ name: bucket, subs: list.map(({ name, sites: s }) => ({ name, sites: s })) });
  }
  const byName = new Map(buckets.map((b) => [b.name, b]));
  const known = ORDER.filter((n) => byName.has(n)).map((n) => byName.get(n));
  const rest = buckets.filter((b) => !ORDER.includes(b.name)).sort((a, b) => a.name.localeCompare(b.name, "zh-CN"));
  return [...known, ...rest];
}
function fail(site, message, ms = 0) {
  return { siteKey: site.key, siteName: site.name, ok: false, ms, message, list: [] };
}
async function browseSite(site, typeIds, page, limit) {
  const started = Date.now();
  try {
    const url = buildCmsBrowseUrl(site, "detail", typeIds, page);
    const text = await fetchText(url, { header: await resolveHeader(site, url) });
    const ms = Date.now() - started;
    const payload = parseLooseJson(text);
    if (!isCmsOk(payload)) {
      const msg = str(payload?.msg) || "接口返回异常";
      return { result: fail(site, `接口返回异常：${msg}`, ms), pageCount: 0 };
    }
    const body = payload;
    const raw = asArray(body.list);
    const list = raw.slice(0, limit).map((item) => cmsItemToVod(item, site));
    const reported = Number(body.pagecount);
    const pageCount = Number.isFinite(reported) && reported > 0 ? reported : list.length ? page + 1 : page;
    if (!list.length) return { result: fail(site, "这个分类下没有返回内容", ms), pageCount };
    return {
      result: {
        siteKey: site.key,
        siteName: site.name,
        ok: true,
        ms,
        message: `返回 ${list.length} 条`,
        list
      },
      pageCount
    };
  } catch (err) {
    return { result: fail(site, err.message, Date.now() - started), pageCount: 0 };
  }
}
function interleave(lists) {
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  const depth = Math.max(0, ...lists.map((l) => l.length));
  for (let i = 0; i < depth; i++) {
    for (const list of lists) {
      const vod = list[i];
      if (!vod || seen.has(vod.vod_id)) continue;
      seen.add(vod.vod_id);
      out.push(vod);
    }
  }
  return out;
}
async function browseCategory(bucket, sub = "", page = 1) {
  const categories = await listCategories();
  const target = categories.find((c) => c.name === bucket);
  if (!target) throw new Error(`没有找到「${bucket}」这个分类`);
  const picked = sub ? target.subs.filter((s) => s.name === sub) : target.subs;
  if (!picked.length) throw new Error(`「${bucket}」下没有「${sub}」这个子分类`);
  const limit = 30;
  const all = await getSites();
  const byKey = new Map(all.map((s) => [s.key, s]));
  const jobs = [];
  for (const s of picked) {
    for (const entry of s.sites) {
      const site = byKey.get(entry.siteKey);
      if (site) jobs.push({ siteKey: entry.siteKey, siteName: entry.siteName, site, ids: entry.typeIds });
    }
  }
  const settings = await getSettings();
  const concurrency = Math.max(1, Math.min(32, settings.concurrency ?? 8));
  const pages = new Array(jobs.length);
  let cursor = 0;
  const worker = async () => {
    for (; ; ) {
      const index = cursor++;
      if (index >= jobs.length) return;
      const job = jobs[index];
      pages[index] = await browseSite(job.site, job.ids, page, limit);
    }
  };
  await Promise.all(Array.from({ length: Math.min(concurrency, jobs.length) }, () => worker()));
  const perSite = /* @__PURE__ */ new Map();
  for (let i = 0; i < jobs.length; i++) {
    const slot = perSite.get(jobs[i].siteKey) ?? { siteName: jobs[i].siteName, results: [] };
    slot.results.push(pages[i].result);
    perSite.set(jobs[i].siteKey, slot);
  }
  const results = [];
  const siteDepth = [];
  for (const [siteKey, slot] of perSite) {
    const ok = slot.results.filter((r) => r.ok);
    const list = interleave(ok.map((r) => r.list)).slice(0, limit);
    if (!list.length) {
      results.push(
        slot.results.find((r) => !r.ok) ?? {
          siteKey,
          siteName: slot.siteName,
          ok: false,
          ms: 0,
          message: "这个分类下没有返回内容",
          list: []
        }
      );
      continue;
    }
    const depths = jobs.map((job, i) => job.siteKey === siteKey ? pages[i].pageCount : 0).filter((n) => n > 0);
    if (depths.length) siteDepth.push(Math.min(...depths));
    results.push({
      siteKey,
      siteName: slot.siteName,
      ok: true,
      ms: Math.max(...slot.results.map((r) => r.ms)),
      message: `返回 ${list.length} 条`,
      list
    });
  }
  const pageCount = Math.max(page, ...siteDepth);
  return { page, pageCount, bucket, sub, results };
}
const LIMIT = 24;
const TTL$1 = 10 * 60 * 1e3;
const ERROR_TTL = 60 * 1e3;
function matchSite(sites, ref) {
  const want = ref.trim();
  if (!want) return void 0;
  const lower = want.toLowerCase();
  return sites.find((s) => s.key === want) ?? sites.find((s) => s.name === want) ?? sites.find((s) => s.key.toLowerCase() === lower || s.name.toLowerCase() === lower) ?? sites.find((s) => s.name.includes(want) || want.includes(s.name));
}
function isCms(site) {
  return (site.type === 3 || site.type === 4) && site.enabled && !site.unsupported && !!site.api;
}
async function buildPlan() {
  const sites = (await getSites()).filter((s) => s.enabled);
  const sources = await listSources();
  const plans = [];
  const missing = [];
  const seen = /* @__PURE__ */ new Set();
  for (const source of sources) {
    if (!source.enabled) continue;
    const sections = getParsed(source.id)?.home?.sections ?? [];
    for (const raw of sections) {
      const title = String(raw?.title ?? "").trim();
      const ref = String(raw?.site ?? "").trim();
      if (!title && !ref) continue;
      const site = matchSite(sites, ref);
      if (!site) {
        missing.push({
          key: `missing:${source.id}:${ref}`,
          title: title || ref,
          origin: "config",
          items: [],
          error: `配置里写的影视源「${ref}」不在当前已启用的源里`
        });
        continue;
      }
      if (!isCms(site)) {
        missing.push({
          key: `unsupported:${source.id}:${site.key}`,
          title: title || site.name,
          origin: "config",
          siteKey: site.key,
          siteName: site.name,
          items: [],
          error: `${site.name} 不是苹果CMS 类型，首页内容位暂时只支持这类源`
        });
        continue;
      }
      const typeId = raw?.typeId === void 0 || raw?.typeId === "" ? void 0 : String(raw.typeId);
      const key = `${site.key}::${typeId ?? "latest"}`;
      if (seen.has(key)) continue;
      seen.add(key);
      plans.push({
        key,
        title: title || (typeId ? `${site.name} · ${typeId}` : `${site.name} · 最近更新`),
        origin: "config",
        site,
        typeId
      });
    }
  }
  if (!plans.length) {
    for (const site of sites) {
      if (!isCms(site)) continue;
      plans.push({
        key: `${site.key}::latest`,
        title: `${site.name} · 最近更新`,
        origin: "default",
        site
      });
    }
  }
  return { plans, missing };
}
async function loadSection(plan) {
  const base = {
    key: plan.key,
    title: plan.title,
    origin: plan.origin,
    siteKey: plan.site.key,
    siteName: plan.site.name
  };
  try {
    const url = plan.typeId ? buildCmsBrowseUrl(plan.site, "detail", [plan.typeId], 1) : buildCmsUrl(plan.site, { ac: "detail", pg: 1 });
    const text = await fetchText(url, { header: await resolveHeader(plan.site, url) });
    const payload = parseLooseJson(text);
    if (!isCmsOk(payload)) {
      const msg = String(payload?.msg ?? "") || "code 非成功";
      return { ...base, items: [], error: `接口返回异常：${msg}` };
    }
    const items = asArray(payload?.list).slice(0, LIMIT).map((item) => cmsItemToVod(item, plan.site));
    if (!items.length) return { ...base, items: [], error: "这一个内容位没有返回数据" };
    return { ...base, items };
  } catch (err) {
    return { ...base, items: [], error: err.message };
  }
}
let cache$1 = null;
async function listHomeSections(force = false) {
  const { plans, missing } = await buildPlan();
  const sig = plans.map((p) => p.key).join("|");
  if (!force && cache$1 && cache$1.sig === sig) {
    const age = Date.now() - cache$1.at;
    const limit = cache$1.sections.some((s) => s.error) ? ERROR_TTL : TTL$1;
    if (age < limit) return [...cache$1.sections, ...missing];
  }
  const settings = await getSettings();
  const concurrency = Math.max(1, Math.min(32, settings.concurrency ?? 8));
  const sections = new Array(plans.length);
  let cursor = 0;
  const worker = async () => {
    for (; ; ) {
      const index = cursor++;
      if (index >= plans.length) return;
      sections[index] = await loadSection(plans[index]);
    }
  };
  await Promise.all(Array.from({ length: Math.min(concurrency, plans.length) }, () => worker()));
  const filled = sections.filter(Boolean);
  cache$1 = { sig, at: Date.now(), sections: filled };
  return [...filled, ...missing];
}
function clearHomeCache() {
  cache$1 = null;
}
const ROOM_URL_RE = /^(huya|douyin):\/\/(\d+)$/i;
function isHttpUrl(url) {
  return /^https?:\/\//i.test((url ?? "").trim());
}
const ADDRESS_RE = /^(https?|rtmp|rtsp|rtp|udp|file|huya|douyin):\/\//i;
function stripDecorator(raw) {
  return raw.replace(/^[\s•·・*\-—]+/, "").replace(/[「」【】《》[\]（）()]/g, "").trim();
}
const GROUP_ALIAS = [
  { re: /^游戏/, name: "游戏赛事" },
  { re: /^影视/, name: "影视轮播" },
  { re: /^咪咕/, name: "咪咕移动" }
];
function normalizeGroup(raw) {
  const name = stripDecorator(raw);
  if (!name) return "其它";
  if (/^(未分组|其他|其它|默认|default|undefined|null)$/i.test(name)) return "其它";
  for (const alias of GROUP_ALIAS) if (alias.re.test(name)) return alias.name;
  return name;
}
function parseM3u(text) {
  const out = [];
  let pending = null;
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line) continue;
    if (line.startsWith("#EXTINF")) {
      const body = line.slice(line.indexOf(":") + 1);
      const comma = body.lastIndexOf(",");
      const attrs = comma >= 0 ? body.slice(0, comma) : body;
      const label = comma >= 0 ? body.slice(comma + 1).trim() : "";
      const pick = (key) => {
        const m = attrs.match(new RegExp(`${key}="([^"]*)"`, "i"));
        return m ? m[1].trim() : "";
      };
      const name = pick("tvg-name") || label;
      pending = {
        name,
        group: pick("group-title"),
        logo: pick("tvg-logo") || void 0
      };
      continue;
    }
    if (line.startsWith("#")) continue;
    if (pending) {
      out.push({
        name: pending.name || line,
        url: line,
        group: normalizeGroup(pending.group),
        logo: pending.logo
      });
      pending = null;
    }
  }
  return out.filter((c) => c.url && c.name);
}
function parseTxt(text) {
  const out = [];
  let group = "其它";
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("//")) continue;
    if (/#genre#?/i.test(line)) {
      group = normalizeGroup(line.split(",")[0]);
      continue;
    }
    if (line.startsWith("#")) continue;
    const idx = line.indexOf(",");
    if (idx <= 0) continue;
    const name = line.slice(0, idx).trim();
    const url = line.slice(idx + 1).trim();
    if (!url) continue;
    if (ADDRESS_RE.test(url)) {
      out.push({ name, url, group });
      continue;
    }
    for (const piece of url.split("#")) {
      const one = piece.trim();
      if (one) out.push({ name, url: one, group });
    }
  }
  return out;
}
function parseLiveContent(text) {
  return /#EXTM3U|#EXTINF/i.test(text) ? parseM3u(text) : parseTxt(text);
}
async function readSource(source, timeout) {
  if (isHttpUrl(source.url)) return fetchText(source.url, { timeout });
  const path = source.url.replace(/^file:\/\/\/?/i, "");
  return promises.readFile(decodeURIComponent(path), "utf8");
}
function mergeChannels(raw) {
  const byName = /* @__PURE__ */ new Map();
  for (const ch of raw) {
    const key = ch.name;
    const hit = byName.get(key);
    if (hit) {
      if (!hit.urls.some((u) => u.url === ch.url)) hit.urls.push({ url: ch.url, source: ch.source });
      if (!hit.logo && ch.logo) hit.logo = ch.logo;
      continue;
    }
    byName.set(key, {
      name: ch.name,
      group: ch.group,
      logo: ch.logo,
      urls: [{ url: ch.url, source: ch.source }]
    });
  }
  const groups = /* @__PURE__ */ new Map();
  for (const ch of byName.values()) {
    let g = groups.get(ch.group);
    if (!g) {
      g = { name: ch.group, channels: [] };
      groups.set(ch.group, g);
    }
    g.channels.push(ch);
  }
  for (const g of groups.values()) g.channels.sort((a, b) => a.name.localeCompare(b.name, "zh-CN"));
  return [...groups.values()].sort((a, b) => {
    if (a.name === "其它") return 1;
    if (b.name === "其它") return -1;
    return b.channels.length - a.channels.length || a.name.localeCompare(b.name, "zh-CN");
  });
}
function collectLiveSources(parsed) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const config of parsed) {
    for (const live of config.lives) {
      const url = (live.url ?? "").trim();
      if (!url || seen.has(url)) continue;
      seen.add(url);
      out.push({ name: live.name || url, url });
    }
  }
  return out;
}
const BUILTIN_LIVE = `游戏赛事,#genre#
danking直播,huya://10188
`;
const BUILTIN_SOURCE = { name: "内置自定义频道", url: "builtin://custom" };
let cache = null;
const TTL = 10 * 60 * 1e3;
let generation = 0;
function clearLiveCache() {
  cache = null;
  generation++;
}
async function loadLive(force = false) {
  if (!force && cache && Date.now() - cache.at < TTL) return cache.result;
  const gen = generation;
  const list = await listSources();
  const parsed = list.filter((s) => s.enabled).map((s) => getParsed(s.id)).filter((p) => Boolean(p));
  const sources = collectLiveSources(parsed);
  const settings = await getSettings();
  const stats = [];
  const all = [];
  const builtin = parseLiveContent(BUILTIN_LIVE);
  for (const ch of builtin) all.push({ ...ch, source: BUILTIN_SOURCE.name });
  stats.push({ ...BUILTIN_SOURCE, channels: builtin.length });
  await Promise.all(
    sources.map(async (source) => {
      try {
        const text = await readSource(source, settings.timeout);
        const channels = parseLiveContent(text);
        if (!channels.length) {
          stats.push({ ...source, channels: 0, error: "没有解析出任何频道，格式可能不兼容" });
          return;
        }
        for (const ch of channels) all.push({ ...ch, source: source.name });
        stats.push({ ...source, channels: channels.length });
      } catch (err) {
        stats.push({ ...source, channels: 0, error: err.message });
      }
    })
  );
  const groups = mergeChannels(all);
  const result = { groups, total: all.length, sources: stats };
  if (gen === generation) cache = { at: Date.now(), result };
  return result;
}
const STORE = "live-health";
const MAX_BYTES = 4096;
const OK_TTL = 30 * 60 * 1e3;
const FAIL_TTL = 5 * 60 * 1e3;
const DEFAULT_TIMEOUT = 6;
const MAX_CONCURRENCY = 8;
const MAX_URLS = 60;
function isFresh(h, now = Date.now()) {
  if (!h?.at) return false;
  return now - h.at < (h.ok ? OK_TTL : FAIL_TTL);
}
async function probeOne(url, timeout, header) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout * 1e3);
  const started = Date.now();
  try {
    const res = await fetch(url, {
      method: "GET",
      redirect: "follow",
      signal: controller.signal,
      headers: { "User-Agent": DEFAULT_UA, Accept: "*/*", ...header }
    });
    if (!res.ok) {
      await res.body?.cancel().catch(() => void 0);
      return { ok: false, ms: Date.now() - started, error: `HTTP ${res.status}` };
    }
    let text = "";
    const reader = res.body?.getReader();
    if (reader) {
      const decoder = new TextDecoder("utf-8");
      let got = 0;
      for (; ; ) {
        const { done, value } = await reader.read();
        if (done) break;
        text += decoder.decode(value, { stream: true });
        got += value.length;
        if (got >= MAX_BYTES) break;
      }
      await reader.cancel().catch(() => void 0);
    }
    const ms = Date.now() - started;
    if (!/#EXTM3U/i.test(text)) {
      const type = res.headers.get("content-type") ?? "";
      return { ok: false, ms, error: type ? `不是 m3u8（${type.split(";")[0]}）` : "返回的不是 m3u8" };
    }
    const bands = [...text.matchAll(/BANDWIDTH=(\d+)/gi)].map((m) => Number(m[1]));
    const heights = [...text.matchAll(/RESOLUTION=\d+x(\d+)/gi)].map((m) => Number(m[1]));
    return {
      ok: true,
      ms,
      bandwidth: bands.length ? Math.max(...bands) : void 0,
      height: heights.length ? Math.max(...heights) : void 0
    };
  } catch (err) {
    const e = err;
    const why = e.name === "AbortError" ? `超时（${timeout}s）` : e.message || "网络错误";
    return { ok: false, ms: Date.now() - started, error: why };
  } finally {
    clearTimeout(timer);
  }
}
async function pool(items, limit, run) {
  const out = new Array(items.length);
  let cursor = 0;
  await Promise.all(
    Array.from({ length: Math.min(limit, items.length) }, async () => {
      for (; ; ) {
        const i = cursor++;
        if (i >= items.length) return;
        out[i] = await run(items[i]);
      }
    })
  );
  return out;
}
async function getHealth() {
  return readStore(STORE, {});
}
async function clearHealth() {
  writeStore(STORE, {});
  return {};
}
async function probeLines(urls, options = {}) {
  const settings = await getSettings();
  const store = await getHealth();
  const now = Date.now();
  const unique = [...new Set(urls.map((u) => u.trim()).filter(Boolean))];
  const targets = unique.filter(isHttpUrl);
  const todo = options.force ? targets : targets.filter((u) => !isFresh(store[u], now)).slice(0, MAX_URLS);
  if (todo.length) {
    const timeout = options.timeout ?? Math.min(settings.timeout, DEFAULT_TIMEOUT * 2);
    const rules = (await listSources()).filter((s) => s.enabled).flatMap((s) => getParsed(s.id)?.headers ?? []);
    const outcomes = await pool(
      todo,
      MAX_CONCURRENCY,
      (url) => probeOne(url, timeout, { "User-Agent": settings.userAgent, ...matchHeaderRules(url, rules) })
    );
    for (let i = 0; i < todo.length; i++) {
      const o = outcomes[i];
      store[todo[i]] = {
        ok: o.ok,
        ms: o.ms,
        at: Date.now(),
        ...o.height ? { height: o.height } : {},
        ...o.bandwidth ? { bandwidth: o.bandwidth } : {},
        ...o.error ? { error: o.error } : {}
      };
    }
    writeStore(STORE, store);
  }
  return store;
}
const TIMEOUT = 12e3;
async function fetchRaw(url, headers, timeout = TIMEOUT) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { "user-agent": DEFAULT_UA, "accept-language": "zh-CN,zh;q=0.9", ...headers },
      redirect: "follow"
    });
    const text = await res.text();
    const cookies = typeof res.headers.getSetCookie === "function" ? res.headers.getSetCookie().map((c) => c.split(";")[0]) : [];
    return { text, cookies };
  } catch (err) {
    const e = err;
    if (e.name === "AbortError") throw new Error(`解析超时（${Math.round(timeout / 1e3)}s）`);
    throw new Error(`解析失败：${e.message}`);
  } finally {
    clearTimeout(timer);
  }
}
async function probePlaylist(url, referer) {
  try {
    const { text } = await fetchRaw(url, { referer, accept: "*/*" }, 8e3);
    if (!text.includes("#EXTM3U")) return { ok: false, media: false };
    return { ok: true, media: text.includes("#EXTINF") };
  } catch {
    return { ok: false, media: false };
  }
}
const REFERER_RULES = [
  { re: /huya\.com/i, referer: "https://www.huya.com/", origin: "https://www.huya.com" },
  {
    re: /(douyin|douyincdn|bytefcdn|volccdn|pstatp|ixigua|bytedance|byteimg|snssdk)\.com/i,
    referer: "https://live.douyin.com/",
    origin: "https://live.douyin.com"
  }
];
function headersFor(url) {
  const rule = REFERER_RULES.find((r) => r.re.test(url));
  if (!rule) return null;
  const headers = { Referer: rule.referer };
  if (url.startsWith("https:")) headers.Origin = rule.origin;
  return headers;
}
async function resolveHuya(roomId) {
  const referer = "https://www.huya.com/";
  const { text } = await fetchRaw(
    `https://mp.huya.com/cache.php?m=Live&do=profileRoom&roomid=${roomId}`,
    { referer, accept: "application/json, text/plain, */*" }
  );
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error("虎牙返回的不是 JSON，接口可能改了");
  }
  const data = json.data;
  if (!data) throw new Error(json.message || "虎牙没有返回房间数据");
  const status = (data.liveStatus ?? "").toUpperCase();
  if (status === "OFF" || status === "") throw new Error("主播当前没有开播");
  if (status === "REPLAY") throw new Error("主播当前没有开播（房间在放录像）");
  const lines = (data.stream?.hls?.multiLine ?? []).filter((l) => /\.m3u8/i.test(l.url ?? ""));
  if (!lines.length) throw new Error("虎牙没有给出 HLS 线路");
  const rank = (t) => t === "HS" ? 0 : t === "AL" ? 2 : 1;
  const ordered = [...lines].sort((a, b) => rank(a.cdnType) - rank(b.cdnType));
  let masterFallback = null;
  for (const line of ordered) {
    const probe = await probePlaylist(line.url, referer);
    if (!probe.ok) continue;
    if (probe.media) return { url: line.url, referer, line: line.cdnType || void 0 };
    if (!masterFallback) masterFallback = line;
  }
  if (masterFallback) {
    return { url: masterFallback.url, referer, line: masterFallback.cdnType || void 0 };
  }
  throw new Error(`虎牙给了 ${lines.length} 条线路，但没有一条能拉下来`);
}
async function resolveDouyin(webRid) {
  const referer = "https://live.douyin.com/";
  const home = await fetchRaw("https://live.douyin.com/", { accept: "text/html" });
  const cookie = home.cookies.join("; ");
  const query = "aid=6383&app_name=douyin_web&live_id=1&device_platform=web&language=zh-CN&enter_from=web_live&cookie_enabled=true&screen_width=1920&screen_height=1080&browser_language=zh-CN&browser_platform=Win32&browser_name=Chrome&browser_version=126.0.0.0";
  const { text } = await fetchRaw(
    `https://live.douyin.com/webcast/room/web/enter/?${query}&web_rid=${webRid}`,
    { referer: `${referer}${webRid}`, cookie, accept: "application/json, text/plain, */*" }
  );
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error("抖音返回的不是 JSON，可能需要签名参数了");
  }
  const room = json.data?.data?.[0];
  if (!room) throw new Error("抖音没有返回房间数据，房间号可能不对");
  const status = Number(room.status ?? 0);
  if (status === 4) throw new Error("主播当前没有开播（本场已结束）");
  if (status !== 2) throw new Error("主播当前没有开播");
  const map = room.stream_url?.hls_pull_url_map ?? {};
  const pick = ["FULL_HD1", "HD1", "SD1", "SD2"].map((k) => map[k]).find(Boolean) ?? Object.values(map)[0];
  if (!pick) throw new Error("抖音没有给出 HLS 线路");
  return { url: pick, referer, line: room.owner?.nickname || void 0 };
}
async function resolveRoomUrl(raw) {
  const url = (raw ?? "").trim();
  const m = url.match(ROOM_URL_RE);
  if (!m) throw new Error(`不认识的房间地址：${url}`);
  const [, platform, roomId] = m;
  return platform.toLowerCase() === "huya" ? resolveHuya(roomId) : resolveDouyin(roomId);
}
const FAVORITES = "favorites";
const HISTORY = "history";
const MAX_HISTORY = 200;
const itemKey = (siteKey, vodId) => `${siteKey}::${vodId}`;
async function readFavorites() {
  const list = await readStore(FAVORITES, []);
  return Array.isArray(list) ? list : [];
}
async function readHistory() {
  const list = await readStore(HISTORY, []);
  return Array.isArray(list) ? list : [];
}
async function listFavorites() {
  const list = await readFavorites();
  return [...list].sort((a, b) => b.addedAt - a.addedAt);
}
function normalizeName(name) {
  const key = name.normalize("NFKC").toLowerCase().replace(/[\s\p{P}\p{S}]/gu, "");
  return key || name.trim().toLowerCase();
}
async function listHistory() {
  const list = await readHistory();
  const groups = /* @__PURE__ */ new Map();
  for (const item of list) {
    const key = normalizeName(item.name);
    const found = groups.get(key);
    if (found) found.items.push(item);
    else groups.set(key, { key, name: item.name, pic: item.pic, items: [item], updatedAt: item.updatedAt });
  }
  const out = [...groups.values()];
  for (const g of out) {
    g.items.sort((a, b) => b.updatedAt - a.updatedAt);
    g.name = g.items[0].name;
    g.pic = g.items[0].pic ?? g.items.find((i) => i.pic)?.pic;
    g.updatedAt = g.items[0].updatedAt;
  }
  return out.sort((a, b) => b.updatedAt - a.updatedAt);
}
async function getLibrary() {
  const [favorites, history] = await Promise.all([listFavorites(), listHistory()]);
  return { favorites, history };
}
async function toggleFavorite(input) {
  const key = itemKey(input.siteKey, input.vodId);
  const list = await readFavorites();
  const idx = list.findIndex((f) => itemKey(f.siteKey, f.vodId) === key);
  if (idx >= 0) {
    list.splice(idx, 1);
    writeStore(FAVORITES, list);
    return { favorited: false };
  }
  list.push({ ...input, addedAt: Date.now() });
  writeStore(FAVORITES, list);
  return { favorited: true };
}
async function removeFavorite(key) {
  const list = await readFavorites();
  writeStore(
    FAVORITES,
    list.filter((f) => itemKey(f.siteKey, f.vodId) !== key)
  );
}
async function clearFavorites() {
  writeStore(FAVORITES, []);
}
async function recordHistory(input) {
  const key = itemKey(input.siteKey, input.vodId);
  const list = await readHistory();
  const idx = list.findIndex((h) => itemKey(h.siteKey, h.vodId) === key);
  const prev = idx >= 0 ? list[idx] : void 0;
  let next = { ...input, updatedAt: Date.now() };
  if (prev && prev.lineIndex === input.lineIndex && prev.epIndex === input.epIndex) {
    const known = input.duration > 0;
    next = {
      ...next,
      position: known ? input.position : prev.position,
      duration: known ? input.duration : prev.duration
    };
  }
  if (idx >= 0) list.splice(idx, 1);
  list.unshift(next);
  const trimmed = list.sort((a, b) => b.updatedAt - a.updatedAt).slice(0, MAX_HISTORY);
  writeStore(HISTORY, trimmed);
}
async function removeHistoryGroup(key) {
  const list = await readHistory();
  writeStore(
    HISTORY,
    list.filter((h) => normalizeName(h.name) !== key)
  );
}
async function clearHistory() {
  writeStore(HISTORY, []);
}
const PROBE_TARGET = "https://www.example.com";
const CONNECT_TIMEOUT = 800;
function parseProxyChain(rule) {
  const out = [];
  const re = /\b(?:PROXY|HTTPS|SOCKS4|SOCKS5)\s+([^\s;:]+):(\d+)/gi;
  let m;
  while (m = re.exec(rule)) {
    const port = Number(m[2]);
    if (port > 0 && port < 65536) out.push({ host: m[1], port });
  }
  return out;
}
function canConnect({ host, port }) {
  return new Promise((resolve) => {
    const socket = node_net.connect({ host, port });
    const finish = (ok) => {
      socket.removeAllListeners();
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(CONNECT_TIMEOUT);
    socket.once("connect", () => finish(true));
    socket.once("timeout", () => finish(false));
    socket.once("error", () => finish(false));
  });
}
async function ensureReachableProxy() {
  try {
    const rule = await electron.session.defaultSession.resolveProxy(PROBE_TARGET);
    const chain = parseProxyChain(rule);
    if (!chain.length) return;
    for (const target of chain) {
      if (await canConnect(target)) return;
    }
    await electron.session.defaultSession.setProxy({ mode: "direct" });
    console.warn(
      `[proxy] 系统代理 ${chain.map((t) => `${t.host}:${t.port}`).join(" / ")} 都连不上，本次运行改为直连`
    );
  } catch (err) {
    console.warn("[proxy] 检查系统代理失败，保持默认设置：", err);
  }
}
function programFiles() {
  const out = [];
  for (const key of ["ProgramFiles", "ProgramFiles(x86)", "ProgramW6432", "LOCALAPPDATA"]) {
    const dir = process.env[key];
    if (dir) out.push(dir);
  }
  const local = process.env["LOCALAPPDATA"];
  if (local) out.push(node_path.join(local, "Programs"));
  return out;
}
function pathDirs() {
  return (process.env["PATH"] ?? "").split(";").filter(Boolean);
}
function candidates() {
  const roots = programFiles();
  const under = (...parts) => roots.map((root) => node_path.join(root, ...parts));
  const onPath = (exe) => pathDirs().map((dir) => node_path.join(dir, exe));
  return [
    {
      name: "PotPlayer",
      paths: [
        ...under("DAUM", "PotPlayer", "PotPlayerMini64.exe"),
        ...under("DAUM", "PotPlayer", "PotPlayerMini.exe"),
        ...under("PotPlayer", "PotPlayerMini64.exe"),
        ...under("PotPlayer", "PotPlayerMini.exe"),
        ...onPath("PotPlayerMini64.exe")
      ]
    },
    {
      name: "mpv",
      paths: [
        ...under("mpv", "mpv.exe"),
        ...under("mpv-player", "mpv.exe"),
        ...under("mpv.net", "mpvnet.exe"),
        ...onPath("mpv.exe")
      ]
    },
    {
      name: "VLC",
      paths: [...under("VideoLAN", "VLC", "vlc.exe"), ...onPath("vlc.exe")]
    },
    {
      name: "MPC-HC",
      paths: [
        ...under("MPC-HC", "mpc-hc64.exe"),
        ...under("MPC-HC64", "mpc-hc64.exe"),
        ...under("K-Lite Codec Pack", "MPC-HC64", "mpc-hc64.exe"),
        ...onPath("mpc-hc64.exe")
      ]
    },
    {
      name: "MPC-BE",
      paths: [...under("MPC-BE x64", "mpc-be64.exe"), ...onPath("mpc-be64.exe")]
    },
    {
      name: "KMPlayer",
      paths: [
        ...under("The KMPlayer", "KMPlayer64.exe"),
        ...under("KMPlayer", "KMPlayer.exe"),
        ...onPath("KMPlayer64.exe")
      ]
    },
    {
      name: "SMPlayer",
      paths: [...under("SMPlayer", "smplayer.exe"), ...onPath("smplayer.exe")]
    }
  ];
}
const DEFAULT_PREFER = [
  "PotPlayer",
  "mpv",
  "VLC",
  "MPC-HC",
  "MPC-BE",
  "KMPlayer",
  "SMPlayer"
];
const ASSOC_EXTS = [".mkv", ".mp4", ".ts", ".flv"];
const NOT_A_PLAYER = /^(mse?edge|chrome|chromium|firefox|brave|opera|quark|vivaldi|360|sogou|qqbrowser|notepad|code|explorer|photos|mspaint|acdsee|wmp11\.assocfile)/i;
function regQuery(args) {
  return new Promise((resolve) => {
    node_child_process.execFile(
      "reg",
      args,
      { windowsHide: true, timeout: 4e3, maxBuffer: 512 * 1024 },
      (err, stdout) => resolve(err ? "" : String(stdout ?? ""))
    );
  });
}
function regValue(out) {
  for (const line of out.split(/\r?\n/)) {
    const m = line.match(/REG_(?:EXPAND_)?SZ\s+(.+)$/);
    if (m) return m[1].trim();
  }
  return "";
}
function exeOf(command) {
  const trimmed = command.trim();
  if (!trimmed) return "";
  const quoted = trimmed.match(/^"([^"]+)"/);
  const raw = quoted ? quoted[1] : trimmed.split(/\s+/)[0];
  return /\.exe$/i.test(raw) ? raw : "";
}
async function fromRegistry() {
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  for (const ext of ASSOC_EXTS) {
    let progId = regValue(
      await regQuery([
        "query",
        `HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FileExts\\${ext}\\UserChoice`,
        "/v",
        "ProgId"
      ])
    );
    if (!progId) {
      progId = regValue(await regQuery(["query", `HKCU\\Software\\Classes\\${ext}`, "/ve"])) || regValue(await regQuery(["query", `HKLM\\Software\\Classes\\${ext}`, "/ve"]));
    }
    if (!progId || NOT_A_PLAYER.test(progId)) continue;
    let command = await regQuery(["query", `HKCU\\Software\\Classes\\${progId}\\shell\\open\\command`, "/ve"]);
    if (!regValue(command)) {
      command = await regQuery(["query", `HKLM\\Software\\Classes\\${progId}\\shell\\open\\command`, "/ve"]);
    }
    const exe = exeOf(regValue(command));
    if (!exe || seen.has(exe.toLowerCase()) || !node_fs.existsSync(exe)) continue;
    seen.add(exe.toLowerCase());
    const name = progId.replace(/\.[a-z0-9]+$/i, "").slice(0, 40) || "系统默认";
    out.push({ name, path: exe, source: "registry" });
  }
  return out;
}
async function detectPlayers() {
  const settings = await getSettings();
  const prefer = settings.externalPlayer.prefer?.length ? settings.externalPlayer.prefer : DEFAULT_PREFER;
  const found = [];
  const seen = /* @__PURE__ */ new Set();
  for (const candidate of candidates()) {
    for (const path of candidate.paths) {
      if (seen.has(path) || !node_fs.existsSync(path)) continue;
      seen.add(path);
      found.push({ name: candidate.name, path, source: "scan" });
      break;
    }
  }
  const rank = (info) => {
    const i = prefer.indexOf(info.name);
    return i < 0 ? prefer.length : i;
  };
  found.sort((a, b) => rank(a) - rank(b));
  try {
    const extra = (await fromRegistry()).filter((info) => !seen.has(info.path));
    for (const info of extra) seen.add(info.path);
    found.push(...extra);
  } catch {
  }
  const manual = settings.externalPlayer.command?.trim();
  if (manual && node_fs.existsSync(manual) && !seen.has(manual)) {
    found.unshift({ name: "设置里指定的", path: manual, source: "manual" });
  }
  return found;
}
async function resolvePlayer() {
  const settings = await getSettings();
  const manual = settings.externalPlayer.command?.trim();
  if (manual) {
    if (node_fs.existsSync(manual)) return manual;
    throw new Error(`设置里指定的播放器不存在：${manual}`);
  }
  const found = await detectPlayers();
  return found[0]?.path ?? null;
}
async function openInPlayer(rawUrl, title = "") {
  const url = (rawUrl ?? "").trim();
  if (!/^(https?|rtmp|rtsp|file):/i.test(url)) {
    throw new Error("播放地址不是受支持的协议");
  }
  const command = await resolvePlayer();
  if (!command) {
    throw new Error("没有找到可用的外部播放器，请在「设置」里手动指定播放器路径");
  }
  const settings = await getSettings();
  const template = settings.externalPlayer.args?.length ? settings.externalPlayer.args : ["{url}"];
  const args = template.map(
    (arg) => arg.replace(/\{url\}/gi, url).replace(/\{title\}/gi, title || "")
  );
  const child = node_child_process.spawn(command, args, { detached: true, stdio: "ignore" });
  child.unref();
  return { player: command, args };
}
const STATS = "parse-stats";
const CUSTOM = "parses";
const PARSE_TIMEOUT = 8;
const PARSE_BUDGET = 24e3;
const SAMPLE_TARGET = "https://v.qq.com/x/cover/mzc00200mp8vo9b.html";
const MEDIA_RE = /\.(m3u8|mp4|flv|mkv|ts|mov|avi|webm|m4v|mpd|mp3|m4a)(\?|#|$)/i;
const DIRECT_RE = /^(https?|rtmp|rtsp|file):\/\//i;
function isDirectMedia(raw) {
  const url = (raw ?? "").trim();
  if (!url) return false;
  if (/^(rtmp|rtsp|file):/i.test(url)) return true;
  return MEDIA_RE.test(url);
}
function buildParseUrl(template, target) {
  const tpl = (template ?? "").trim();
  if (!tpl) throw new Error("解析接口地址为空");
  if (/\{url\}/i.test(tpl)) return tpl.replace(/\{url\}/gi, encodeURIComponent(target));
  if (/[?&][^=&]*=$/.test(tpl)) return tpl + encodeURIComponent(target);
  const sep = tpl.includes("?") ? "&" : "?";
  return `${tpl}${sep}url=${encodeURIComponent(target)}`;
}
function unescapeUrl(raw) {
  return raw.replace(/\\\//g, "/").replace(/\\u002[fF]/g, "/").replace(/\\u0026/gi, "&").replace(/&amp;/g, "&").trim();
}
const URL_KEYS = ["url", "playurl", "play_url", "m3u8", "src", "video", "link", "address"];
const NON_MEDIA_RE = /\.(js|mjs|cjs|css|json|xml|html?|png|jpe?g|gif|webp|svg|ico|woff2?|ttf|eot|map|txt|apk|zip)(\?|#|$)/i;
function looksLikeStream(url) {
  if (isDirectMedia(url)) return true;
  return !NON_MEDIA_RE.test(url);
}
function asPlayable(value) {
  if (typeof value !== "string") return null;
  const url = unescapeUrl(value);
  if (!DIRECT_RE.test(url) || /\s/.test(url)) return null;
  return url;
}
function scanMediaUrl(text) {
  const flat = unescapeUrl(text);
  const hls = /https?:\/\/[^\s'"<>()]+\.m3u8(?:\?[^\s'"<>()]*)?/i.exec(flat);
  if (hls) return hls[0];
  const other = /https?:\/\/[^\s'"<>()]+\.(?:mp4|flv|mkv|mov|webm|m4v|mpd)(?:\?[^\s'"<>()]*)?/i.exec(flat);
  return other ? other[0] : null;
}
function deepFindUrl(node, depth = 0) {
  if (node == null || depth > 4) return null;
  const direct = asPlayable(node);
  if (direct) return direct;
  if (Array.isArray(node)) {
    for (const item of node) {
      const hit = deepFindUrl(item, depth + 1);
      if (hit) return hit;
    }
    return null;
  }
  if (typeof node !== "object") return null;
  const obj = node;
  for (const key of Object.keys(obj)) {
    if (!URL_KEYS.includes(key.toLowerCase())) continue;
    const hit = deepFindUrl(obj[key], depth + 1);
    if (hit) return hit;
  }
  for (const key of ["data", "result", "info", "content"]) {
    if (key in obj) {
      const hit = deepFindUrl(obj[key], depth + 1);
      if (hit) return hit;
    }
  }
  return null;
}
function extractUrl(body, options = {}) {
  const text = (body ?? "").trim();
  if (!text) return null;
  const accept = (value) => {
    if (!value) return null;
    if (options.requireMedia) return isDirectMedia(value) ? value : null;
    return looksLikeStream(value) ? value : null;
  };
  const bare = accept(asPlayable(text));
  if (bare) return bare;
  try {
    const hit = accept(deepFindUrl(parseLooseJson(text)));
    if (hit) return hit;
  } catch {
  }
  const scanned = scanMediaUrl(text);
  if (scanned) return scanned;
  const patterns = [
    /\bvar\s+main\s*=\s*['"]([^'"]+)['"]/i,
    /\bvar\s+url\s*=\s*['"]([^'"]+)['"]/i,
    /"url"\s*:\s*"([^"]+)"/i,
    /'url'\s*:\s*'([^']+)'/i,
    /"playUrl"\s*:\s*"([^"]+)"/i,
    /<video[^>]+src=["']([^"']+)["']/i,
    /<source[^>]+src=["']([^"']+)["']/i,
    /(?:src|url)\s*=\s*["'](https?:\\?\/\\?\/[^"']+)["']/i
  ];
  for (const re of patterns) {
    for (const m of text.matchAll(new RegExp(re.source, `${re.flags.replace("g", "")}g`))) {
      const url = accept(asPlayable(m[1]));
      if (url) return url;
    }
  }
  const pm = /player_aaaa\s*=\s*(\{[\s\S]*?\})\s*;?\s*<\/script>/i.exec(text);
  if (pm) {
    try {
      const data = JSON.parse(pm[1]);
      const hit = accept(deepFindUrl(data));
      if (hit) return hit;
    } catch {
    }
  }
  return null;
}
function extractRedirect(body, base) {
  const text = (body ?? "").trim();
  if (!text) return null;
  const patterns = [
    /<meta[^>]+http-equiv=["']?refresh["']?[^>]*content=["'][^"']*?url=([^"';\s>]+)/i,
    /content=["'][^"']*?url=([^"';\s>]+)["'][^>]*http-equiv=["']?refresh/i,
    /(?:window\.)?location\.href\s*=\s*['"]([^'"]+)['"]/i,
    /(?:window\.)?location\.replace\(\s*['"]([^'"]+)['"]/i,
    /(?:window\.)?location\s*=\s*['"]([^'"]+)['"]/i
  ];
  for (const re of patterns) {
    const m = re.exec(text);
    if (!m) continue;
    const raw = unescapeUrl(m[1]);
    if (!/^https?:\/\//i.test(raw)) continue;
    try {
      const resolved = new URL(raw, base).toString();
      if (resolved !== base) return resolved;
    } catch {
    }
  }
  return null;
}
function flagsOf(item) {
  const ext = item.ext;
  const raw = ext?.flag;
  if (Array.isArray(raw)) return raw.map((v) => String(v).trim()).filter(Boolean);
  if (typeof raw === "string") {
    return raw.split(/[,|]/).map((v) => v.trim()).filter(Boolean);
  }
  return [];
}
async function configParses() {
  const sources = await listSources();
  const out = [];
  for (const source of sources) {
    if (!source.enabled) continue;
    const parsed = getParsed(source.id);
    if (parsed?.parses?.length) out.push(...parsed.parses);
  }
  return out;
}
function emptyStat() {
  return { ok: 0, fail: 0, lastOk: 0, lastMs: 0 };
}
async function listParses() {
  const stats = await readStore(STATS, {});
  const custom = await readStore(CUSTOM, []);
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  const push = (item, origin) => {
    const url = (item.url ?? "").trim();
    if (!url || seen.has(url)) return;
    seen.add(url);
    const name = (item.name ?? "").trim();
    out.push({
      name: name || url,
      type: Number(item.type ?? 1),
      url,
      ext: item.ext,
      origin,
      flags: flagsOf(item),
      stat: stats[url] ?? emptyStat()
    });
  };
  for (const item of await configParses()) push(item, "config");
  for (const item of Array.isArray(custom) ? custom : []) push(item, "custom");
  return out;
}
async function addParse(input) {
  const url = (input.url ?? "").trim();
  if (!/^https?:\/\//i.test(url)) throw new Error("解析接口地址要以 http(s):// 开头");
  const all = await listParses();
  if (all.some((p) => p.url === url)) throw new Error("这条解析接口已经有了");
  const custom = await readStore(CUSTOM, []);
  const flags = (input.flags ?? []).map((f) => f.trim()).filter(Boolean);
  custom.push({
    name: (input.name ?? "").trim() || url,
    type: Number(input.type ?? 1),
    url,
    ext: flags.length ? { flag: flags } : void 0
  });
  writeStore(CUSTOM, custom);
  return listParses();
}
async function removeParse(url) {
  const custom = await readStore(CUSTOM, []);
  writeStore(
    CUSTOM,
    custom.filter((item) => (item.url ?? "").trim() !== url.trim())
  );
  return listParses();
}
async function resetParseStats() {
  writeStore(STATS, {});
  return listParses();
}
function scoreOf(stat) {
  const rate = (stat.ok + 1) / (stat.ok + stat.fail + 2);
  const speed = stat.lastMs > 0 ? Math.max(0, 1 - Math.min(stat.lastMs, 8e3) / 8e3) : 0.5;
  return rate * 2 + speed;
}
function orderParses(list, flag2, prefer) {
  const tier = (p) => {
    if (prefer && (p.name === prefer || p.url === prefer)) return 0;
    const flags = p.flags;
    if (flags.length && flag2 && flags.some((f) => f.toLowerCase() === flag2.toLowerCase())) return 1;
    if (!flags.length) return 2;
    return 3;
  };
  const kind = (p) => p.type === 0 ? 1 : 0;
  return [...list].sort((a, b) => {
    const t = tier(a) - tier(b);
    if (t !== 0) return t;
    const k = kind(a) - kind(b);
    if (k !== 0) return k;
    return scoreOf(b.stat) - scoreOf(a.stat);
  });
}
function headersOf(item) {
  const ext = item.ext;
  const out = {};
  if (ext?.header && typeof ext.header === "object") {
    for (const [k, v] of Object.entries(ext.header)) {
      if (typeof v === "string") out[k] = v;
    }
  }
  if (!out.Referer) out.Referer = item.url;
  return out;
}
const MAX_HOPS = 3;
async function walk(start, headers, label, strict = false) {
  const started = Date.now();
  let current = start;
  try {
    for (let hop = 0; hop < MAX_HOPS; hop++) {
      const api = current;
      const res = await request(api, { timeout: PARSE_TIMEOUT, header: headers });
      const ms = Date.now() - started;
      if (res.finalUrl && res.finalUrl !== api && isDirectMedia(res.finalUrl)) {
        return { name: label, ok: true, ms, url: res.finalUrl };
      }
      const text = decodeResponse(res);
      const found = extractUrl(text, { requireMedia: strict });
      if (found && found !== api) return { name: label, ok: true, ms, url: found };
      const next = extractRedirect(text, res.finalUrl || api);
      if (!next || next === api) break;
      current = next;
    }
    return {
      name: label,
      ok: false,
      ms: Date.now() - started,
      error: current === start ? "没有拿到可识别的播放地址" : "跟着跳转找了几跳，还是没拿到播放地址"
    };
  } catch (err) {
    return { name: label, ok: false, ms: Date.now() - started, error: err.message };
  }
}
const DIRECT_LABEL = "直接从播放页里取";
async function tryDirect(target) {
  const headers = {};
  try {
    headers.Referer = `${new URL(target).origin}/`;
  } catch {
  }
  return walk(target, headers, DIRECT_LABEL, true);
}
async function tryParse(item, target) {
  return walk(buildParseUrl(item.url, target), headersOf(item), item.name);
}
async function recordStat(url, attempt) {
  const stats = await readStore(STATS, {});
  const cur = stats[url] ?? emptyStat();
  stats[url] = attempt.ok ? { ok: cur.ok + 1, fail: cur.fail, lastOk: Date.now(), lastMs: attempt.ms } : {
    ok: cur.ok,
    fail: cur.fail + 1,
    lastOk: cur.lastOk,
    lastMs: cur.lastMs,
    lastError: attempt.error
  };
  writeStore(STATS, stats);
}
async function resolvePlayUrl(rawUrl, options = {}) {
  const url = (rawUrl ?? "").trim();
  if (!url) throw new Error("没有播放地址");
  if (isDirectMedia(url)) {
    return { ok: true, url, direct: true, ms: 0, attempts: [] };
  }
  const list = await listParses();
  const started = Date.now();
  const attempts = [];
  const direct = await tryDirect(url);
  attempts.push(direct);
  if (direct.ok && direct.url) {
    return {
      ok: true,
      url: direct.url,
      direct: false,
      parseName: direct.name,
      ms: Date.now() - started,
      attempts
    };
  }
  if (!list.length) {
    return {
      ok: false,
      url: "",
      direct: false,
      ms: Date.now() - started,
      attempts,
      error: "这个地址是网页而不是直链，播放页里也没找到播放地址，而配置里一条解析接口都没有"
    };
  }
  const ordered = orderParses(list, options.flag, options.prefer);
  for (const item of ordered) {
    if (Date.now() - started > PARSE_BUDGET) {
      attempts.push({ name: item.name, ok: false, ms: 0, error: "整体超时，没轮到这条" });
      continue;
    }
    const attempt = await tryParse(item, url);
    attempts.push(attempt);
    await recordStat(item.url, attempt);
    if (attempt.ok && attempt.url) {
      return {
        ok: true,
        url: attempt.url,
        direct: false,
        parseName: attempt.name,
        ms: Date.now() - started,
        attempts
      };
    }
  }
  const reason = attempts.find((a) => a.error)?.error ?? "未知原因";
  return {
    ok: false,
    url: "",
    direct: false,
    ms: Date.now() - started,
    attempts,
    error: `${attempts.length} 条路子都没能换出地址（${reason}）`
  };
}
async function testParse(parseUrl, target) {
  const use = (target ?? "").trim() || SAMPLE_TARGET;
  const list = await listParses();
  const item = list.find((p) => p.url === parseUrl);
  if (!item) throw new Error("没有这条解析接口");
  const attempt = await tryParse(item, use);
  await recordStat(item.url, attempt);
  return {
    ok: attempt.ok,
    ms: attempt.ms,
    target: use,
    url: attempt.url,
    error: attempt.error
  };
}
const BUNDLED_FLAG = "bundled-sources";
const PUBLIC_CMS = {
  id: "public-cms",
  name: "公开可用源（苹果CMS 采集站）",
  desc: "实测存活的 5 个公开采集接口 + 2 个公开直播源。这类源随时可能失效，失效后在「影视源」「电视直播」页一看便知。",
  siteCount: 5,
  liveCount: 2,
  config: {
    format: "tvbox-desktop/1",
    name: "公开可用源（苹果CMS 采集站）",
    note: "实测存活的公开采集接口，全部是标准苹果CMS v10 的 /api.php/provide/vod。判断标准有三条：列表接口有数据、带 wd 的搜索有结果、详情能解析出剧集地址。直播源一 txt 一 m3u，用来覆盖两种解析格式。",
    sites: [
      {
        key: "ffzy",
        name: "非凡资源",
        type: "cms",
        api: "https://api.ffzyapi.com/api.php/provide/vod",
        searchable: 1
      },
      {
        key: "lzi",
        name: "量子资源",
        type: "cms",
        api: "https://cj.lziapi.com/api.php/provide/vod",
        searchable: 1
      },
      {
        key: "dyttzy",
        name: "电影天堂资源",
        type: "cms",
        api: "https://caiji.dyttzyapi.com/api.php/provide/vod",
        searchable: 1
      },
      {
        key: "guangsu",
        name: "光速资源",
        type: "cms",
        api: "https://api.guangsuapi.com/api.php/provide/vod",
        searchable: 1
      },
      {
        key: "subo",
        name: "素博资源",
        type: "cms",
        api: "https://subocaiji.com/api.php/provide/vod",
        searchable: 1
      }
    ],
    // 只留 IPv4 那一条。实测 Gather.m3u 的 123 条线路里 108 条（88%）拉不起来，
    // 而且它和 iptv4.txt 一个重名的频道都没有（补不上线路），留着只会让频道列表
    // 里多出一堆点开就失败的卡。
    lives: [
      {
        name: "公开直播源·IPv4（txt）",
        type: 0,
        url: "https://live.zbds.top/tv/iptv4.txt"
      }
    ],
    // 首页内容位。写在这里的行优先于「每个源一条最近更新」的默认行为，
    // 让首启就有几行带分类的内容，而不是五条一模一样的「最近更新」。
    // typeId 用的是苹果CMS v10 的默认分类 id（6=动作片、13=国产剧、42=日本动漫），
    // 这五条都在真实源上逐条验证过 20 条有内容。
    tvboxDesktop: {
      home: {
        sections: [
          { title: "电影 · 最近更新", site: "dyttzy" },
          { title: "电影 · 动作片", site: "ffzy", typeId: 6 },
          { title: "电视剧 · 国产剧", site: "lzi", typeId: 13 },
          { title: "动漫 · 日本", site: "guangsu", typeId: 42 },
          { title: "综艺 · 最近更新", site: "subo" }
        ]
      }
    }
  }
};
const SOURCE_PRESETS = [PUBLIC_CMS];
function listPresets() {
  return SOURCE_PRESETS.map(({ id, name, desc, siteCount, liveCount }) => ({
    id,
    name,
    desc,
    siteCount,
    liveCount
  }));
}
async function addPreset(id) {
  const preset = SOURCE_PRESETS.find((p) => p.id === id);
  if (!preset) throw new Error("没有这个内置订阅");
  const dir = node_path.join(electron.app.getPath("userData"), "presets");
  node_fs.mkdirSync(dir, { recursive: true });
  const file = node_path.join(dir, `${preset.id}.json`);
  node_fs.writeFileSync(file, JSON.stringify(preset.config, null, 2), "utf8");
  const existing = await listSources();
  const already = existing.find((s) => s.url === file);
  if (already) throw new Error("这个内置订阅已经添加过了");
  return addSource({ name: preset.name, url: file, kind: "file" });
}
async function ensureBundledSources() {
  if (SOURCE_PRESETS.length === 0) return false;
  if (await readStore(BUNDLED_FLAG, false)) return false;
  const existing = await listSources();
  if (existing.length) {
    await writeStore(BUNDLED_FLAG, true);
    return false;
  }
  try {
    const source = await addPreset(SOURCE_PRESETS[0].id);
    await writeStore(BUNDLED_FLAG, true);
    await syncSource(source.id);
    return true;
  } catch (err) {
    console.error("[presets] 首启写入内置订阅失败：", err);
    return false;
  }
}
const DATA_DIR = node_path.join(electron.app.isPackaged ? node_path.dirname(electron.app.getPath("exe")) : electron.app.getAppPath(), "data");
function migrateLegacyData(legacy) {
  if (legacy === DATA_DIR) return;
  for (const name of ["settings", "sources", "sites"]) {
    const from = node_path.join(legacy, `${name}.json`);
    const to = node_path.join(DATA_DIR, `${name}.json`);
    if (node_fs.existsSync(to) || !node_fs.existsSync(from)) continue;
    try {
      node_fs.copyFileSync(from, to);
    } catch {
    }
  }
}
function redirectUserData() {
  const legacy = electron.app.getPath("userData");
  try {
    node_fs.mkdirSync(DATA_DIR, { recursive: true });
    electron.app.setPath("userData", DATA_DIR);
    electron.app.setPath("sessionData", node_path.join(DATA_DIR, "session"));
  } catch (err) {
    console.error("[data] 无法切到便携数据目录，继续用默认目录：", err);
    return;
  }
  migrateLegacyData(legacy);
}
redirectUserData();
let mainWindow = null;
async function createWindow() {
  const saved = (await getSettings()).window;
  mainWindow = new electron.BrowserWindow({
    width: saved.width || DEFAULT_SETTINGS.window.width,
    height: saved.height || DEFAULT_SETTINGS.window.height,
    minWidth: 1100,
    minHeight: 700,
    show: false,
    // 纯白风格：先把底色刷白，避免启动瞬间的黑屏闪烁
    backgroundColor: "#ffffff",
    autoHideMenuBar: true,
    webPreferences: {
      preload: node_path.join(__dirname, "../preload/index.js"),
      sandbox: false,
      contextIsolation: true,
      nodeIntegration: false,
      // 必须关掉：渲染进程的页面源是 file://，而海报图与 m3u8 分片大多来自
      // 第三方 http(s) 站点，hls.js 用 XHR 拉分片时会被同源策略拦下。
      webSecurity: false
    }
  });
  mainWindow.on("ready-to-show", () => mainWindow?.show());
  let resizeTimer = null;
  mainWindow.on("resize", () => {
    if (resizeTimer) clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      if (!mainWindow || mainWindow.isMaximized() || mainWindow.isMinimized()) return;
      const [width, height] = mainWindow.getSize();
      void saveSettings({ window: { width, height } });
    }, 400);
  });
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    void electron.shell.openExternal(url);
    return { action: "deny" };
  });
  const devUrl = process.env["ELECTRON_RENDERER_URL"];
  if (devUrl) {
    void mainWindow.loadURL(devUrl);
  } else {
    void mainWindow.loadFile(node_path.join(__dirname, "../renderer/index.html"));
  }
}
function registerIpc() {
  electron.ipcMain.handle(IPC.appInfo, () => {
    return {
      version: electron.app.getVersion(),
      electron: process.versions.electron,
      chrome: process.versions.chrome,
      node: process.versions.node,
      platform: `${process.platform} ${process.arch}`,
      userData: electron.app.getPath("userData")
    };
  });
  electron.ipcMain.handle(IPC.openExternal, async (_e, url) => {
    if (!/^https?:\/\//i.test(url)) throw new Error("仅支持打开 http/https 链接");
    await electron.shell.openExternal(url);
  });
  electron.ipcMain.handle(IPC.settingsGet, () => getSettings());
  electron.ipcMain.handle(IPC.settingsSet, (_e, patch) => saveSettings(patch));
  electron.ipcMain.handle(IPC.sourcesList, () => listSources());
  electron.ipcMain.handle(IPC.sourcesAdd, async (_e, input) => {
    const result = await addSource(input);
    clearLiveCache();
    clearCategoryCache();
    clearHomeCache();
    return result;
  });
  electron.ipcMain.handle(IPC.sourcesUpdate, async (_e, id, patch) => {
    const result = await updateSource(id, patch);
    clearLiveCache();
    clearCategoryCache();
    clearHomeCache();
    return result;
  });
  electron.ipcMain.handle(IPC.sourcesRemove, async (_e, id) => {
    await removeSource(id);
    clearLiveCache();
    clearCategoryCache();
    clearHomeCache();
  });
  electron.ipcMain.handle(IPC.sourcesSync, async (_e, id) => {
    const result = await syncSource(id);
    clearLiveCache();
    clearCategoryCache();
    clearHomeCache();
    return result;
  });
  electron.ipcMain.handle(IPC.sourcesSyncAll, async () => {
    const result = await syncAll();
    clearLiveCache();
    clearCategoryCache();
    clearHomeCache();
    return result;
  });
  electron.ipcMain.handle(IPC.sourcesPickFile, async () => {
    if (!mainWindow) return null;
    const result = await electron.dialog.showOpenDialog(mainWindow, {
      title: "选择配置文件",
      filters: [{ name: "JSON 配置", extensions: ["json"] }],
      properties: ["openFile"]
    });
    return result.canceled ? null : result.filePaths[0] ?? null;
  });
  electron.ipcMain.handle(IPC.sourcesPresets, () => listPresets());
  electron.ipcMain.handle(IPC.sourcesAddPreset, (_e, id) => addPreset(id));
  electron.ipcMain.handle(IPC.sitesList, () => getSites());
  electron.ipcMain.handle(
    IPC.sitesSetEnabled,
    (_e, key, enabled) => setSiteEnabled(key, enabled)
  );
  electron.ipcMain.handle(
    IPC.sitesSetAllEnabled,
    (_e, keys, enabled) => setSitesEnabled(keys, enabled)
  );
  electron.ipcMain.handle(IPC.sitesTest, (_e, key) => testSite(key));
  electron.ipcMain.handle(
    IPC.searchRun,
    async (_e, wd, options) => {
      return searchAll(wd, options ?? {}, (result, done, total) => {
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send(IPC.searchProgress, { wd, done, total, result });
        }
      });
    }
  );
  electron.ipcMain.handle(IPC.searchCancel, () => {
    cancelSearch();
  });
  electron.ipcMain.handle(
    IPC.detailGet,
    (_e, siteKey, vodId) => getVodDetail(siteKey, vodId)
  );
  electron.ipcMain.handle(IPC.categoryList, () => listCategories());
  electron.ipcMain.handle(
    IPC.categoryBrowse,
    (_e, bucket, sub, page) => browseCategory(bucket, sub, page)
  );
  electron.ipcMain.handle(IPC.liveLoad, (_e, force) => loadLive(Boolean(force)));
  electron.ipcMain.handle(IPC.liveResolve, (_e, url) => resolveRoomUrl(url));
  electron.ipcMain.handle(IPC.liveHealth, () => getHealth());
  electron.ipcMain.handle(
    IPC.liveProbe,
    (_e, urls, options) => probeLines(Array.isArray(urls) ? urls : [], options ?? {})
  );
  electron.ipcMain.handle(IPC.liveClearHealth, () => clearHealth());
  electron.ipcMain.handle(IPC.libraryGet, () => getLibrary());
  electron.ipcMain.handle(
    IPC.libraryToggleFavorite,
    (_e, input) => toggleFavorite(input)
  );
  electron.ipcMain.handle(IPC.libraryRemoveFavorite, (_e, key) => removeFavorite(key));
  electron.ipcMain.handle(IPC.libraryClearFavorites, () => clearFavorites());
  electron.ipcMain.handle(
    IPC.libraryRecord,
    (_e, input) => recordHistory(input)
  );
  electron.ipcMain.handle(IPC.libraryRemoveHistory, (_e, key) => removeHistoryGroup(key));
  electron.ipcMain.handle(IPC.libraryClearHistory, () => clearHistory());
  electron.ipcMain.handle(IPC.playerDetect, () => detectPlayers());
  electron.ipcMain.handle(IPC.playerOpen, (_e, url, title) => openInPlayer(url, title));
  electron.ipcMain.handle(IPC.parseList, () => listParses());
  electron.ipcMain.handle(
    IPC.parseResolve,
    (_e, url, options) => resolvePlayUrl(url, options)
  );
  electron.ipcMain.handle(IPC.parseTest, (_e, url, target) => testParse(url, target));
  electron.ipcMain.handle(
    IPC.parseAdd,
    (_e, input) => addParse(input)
  );
  electron.ipcMain.handle(IPC.parseRemove, (_e, url) => removeParse(url));
  electron.ipcMain.handle(IPC.parseResetStats, () => resetParseStats());
  electron.ipcMain.handle(IPC.homeSections, (_e, force) => listHomeSections(force === true));
  electron.ipcMain.handle(IPC.aiSummary, (_e, input) => summarizeEpisode(input));
  electron.ipcMain.handle(
    IPC.aiSummaryVisual,
    (_e, input, frames) => summarizeEpisodeVisual(input, frames)
  );
}
void electron.app.whenReady().then(async () => {
  electron.app.setAppUserModelId("com.tvbox.desktop");
  await ensureReachableProxy();
  electron.session.defaultSession.webRequest.onBeforeSendHeaders(
    { urls: ["*://*/*"] },
    (details, callback) => {
      const extra = headersFor(details.url);
      if (extra) Object.assign(details.requestHeaders, extra);
      callback({ requestHeaders: details.requestHeaders });
    }
  );
  registerIpc();
  await hydrate();
  await ensureBundledSources();
  await createWindow();
  electron.app.on("activate", () => {
    if (electron.BrowserWindow.getAllWindows().length === 0) void createWindow();
  });
});
electron.app.on("window-all-closed", () => {
  if (process.platform !== "darwin") electron.app.quit();
});
electron.app.on("before-quit", () => {
  void flushStore();
});

// esbuild build script for TVBox Desktop -> WebView main-process bundle.
const esbuild = require("esbuild");
const path = require("path");
const fs = require("fs");

const ROOT = __dirname;
const SRC = path.join(ROOT, "main.process.js");
const OUT = path.join(ROOT, "..", "renderer", "assets", "main.bundle.js");

// Preprocess: patch search progress to emit a DOM event the bridge listens to.
let code = fs.readFileSync(SRC, "utf8");
const needle = "mainWindow.webContents.send(IPC.searchProgress, { wd, done, total, result });";
const replacement =
  "window.dispatchEvent(new CustomEvent('tvbox:search-progress', { detail: { wd, done, total, result } }));\n" +
  "          if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send(IPC.searchProgress, { wd, done, total, result });";
if (code.includes(needle)) {
  code = code.replace(needle, replacement);
  console.log("[build] patched search progress event");
}
const PATCHED = path.join(ROOT, ".main.patched.js");
fs.writeFileSync(PATCHED, code);

const alias = {
  "electron": path.join(ROOT, "shims", "electron.js"),
  "node:fs": path.join(ROOT, "shims", "fs.js"),
  "fs": path.join(ROOT, "shims", "fs.js"),
  "node:fs/promises": path.join(ROOT, "shims", "fs.js"),
  "fs/promises": path.join(ROOT, "shims", "fs.js"),
  "node:path": path.join(ROOT, "shims", "path.js"),
  "path": path.join(ROOT, "shims", "path.js"),
  "node:crypto": path.join(ROOT, "shims", "crypto.js"),
  "crypto": path.join(ROOT, "shims", "crypto.js"),
  "node:net": path.join(ROOT, "shims", "net.js"),
  "net": path.join(ROOT, "shims", "net.js"),
  "node:child_process": path.join(ROOT, "shims", "child_process.js"),
  "child_process": path.join(ROOT, "shims", "child_process.js"),
  "buffer": require.resolve("buffer"),
  "string_decoder": require.resolve("string_decoder"),
};
// Provide a browser-safe stub for Node core modules that deep dependencies
// may reference but that never actually execute on the Android path.
const stubModules = ["stream", "util", "events"];
const stubDir = path.join(ROOT, "shims", "stubs");
if (!fs.existsSync(stubDir)) fs.mkdirSync(stubDir, { recursive: true });
for (const name of stubModules) {
  const f = path.join(stubDir, name + ".js");
  if (!fs.existsSync(f)) fs.writeFileSync(f, "// stub for browser bundle\nmodule.exports = {};\nmodule.exports.default = module.exports;\n");
  alias[name] = f;
}

esbuild.buildSync({
  entryPoints: [PATCHED],
  bundle: true,
  outfile: OUT,
  format: "iife",
  platform: "browser",
  target: ["es2020"],
  alias,
  define: {
    "process.env.NODE_ENV": '"production"',
    "__dirname": '"/data/tvbox"',
    "__filename": '"/data/tvbox/main.js"',
  },
  inject: [
    path.join(ROOT, "shims", "buffer.inject.js"),
    path.join(ROOT, "shims", "process.inject.js"),
  ],
  logLevel: "info",
  legalComments: "none",
});

console.log("[build] wrote", OUT, fs.statSync(OUT).size, "bytes");

// Provides a minimal `process` global so bundled Node-style code works in browser.
// Values are chosen to mirror the desktop Electron runtime.
if (typeof globalThis.process === "undefined") {
  globalThis.process = {
    platform: "win32",
    arch: "x64",
    env: {},
    versions: { electron: "44.4.5", chrome: "130.0.0.0", node: "22.0.0" },
    nextTick: (fn) => Promise.resolve().then(fn),
  };
}
export {};

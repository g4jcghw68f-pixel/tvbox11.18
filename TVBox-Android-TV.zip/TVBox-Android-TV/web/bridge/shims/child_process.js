// Browser shim for node:child_process.
// - execFile("reg", ...) : Windows registry lookup for external players -> return empty
// - spawn(player, args)  : delegate to the native Android bridge (open external app / intent)
// - exec(cmd)            : unsupported -> empty

function bridge() {
  return globalThis.TVBoxBridge || globalThis.Android || null;
}

function execFile(file, args, options, callback) {
  if (typeof options === "function") { callback = options; options = {}; }
  // reg.exe queries have no meaning on Android
  const result = { stdout: "", stderr: "" };
  if (callback) setTimeout(() => callback(null, result.stdout, result.stderr), 0);
  return { kill() {}, unref() {} };
}

function exec(command, options, callback) {
  if (typeof options === "function") { callback = options; options = {}; }
  if (callback) setTimeout(() => callback(new Error("unsupported on android"), "", ""), 0);
  return { kill() {}, unref() {} };
}

function spawn(command, args, options) {
  const b = bridge();
  const url = Array.isArray(args) ? args.find((a) => /^https?:\/\//i.test(String(a))) : "";
  try {
    if (b && typeof b.openExternal === "function") b.openExternal(String(url || command));
    else if (globalThis.window) globalThis.open(String(url || command), "_blank");
  } catch (e) {
    console.warn("[cp] spawn bridge failed", e);
  }
  return { unref() {}, kill() {}, on() {}, stdout: null, stderr: null };
}

module.exports = { execFile, exec, spawn, spawnSync: () => ({ status: 1 }) };

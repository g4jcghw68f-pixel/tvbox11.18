// Browser shim for node:fs / node:fs/promises backed by localStorage.
// The desktop app stores small JSON files in a portable data/ dir. On Android
// we map every file path to a localStorage key, so behaviour stays identical
// from the caller's perspective.

const PREFIX = "tvbox:fs:";

function keyOf(p) {
  return PREFIX + String(p).replace(/\\/g, "/");
}

function readSync(p, encoding) {
  const raw = globalThis.localStorage.getItem(keyOf(p));
  if (raw === null) {
    const err = new Error(`ENOENT: no such file or directory, open '${p}'`);
    err.code = "ENOENT";
    throw err;
  }
  return encoding === "utf-8" || encoding === "utf8" ? raw : raw;
}

function writeSync(p, data) {
  globalThis.localStorage.setItem(keyOf(p), String(data));
}

function existsSync(p) {
  try {
    return globalThis.localStorage.getItem(keyOf(p)) !== null;
  } catch {
    return false;
  }
}

function mkdirSync() {}
function mkdir() { return Promise.resolve(); }

function renameSync(oldPath, newPath) {
  const v = globalThis.localStorage.getItem(keyOf(oldPath));
  if (v === null) return;
  globalThis.localStorage.setItem(keyOf(newPath), v);
  globalThis.localStorage.removeItem(keyOf(oldPath));
}
function rename(oldPath, newPath) {
  renameSync(oldPath, newPath);
  return Promise.resolve();
}

function copyFileSync(src, dest) {
  const v = globalThis.localStorage.getItem(keyOf(src));
  if (v !== null) globalThis.localStorage.setItem(keyOf(dest), v);
}

function unlinkSync(p) { globalThis.localStorage.removeItem(keyOf(p)); }
function unlink(p) { globalThis.localStorage.removeItem(keyOf(p)); return Promise.resolve(); }

function readFileSync(p, encoding) { return readSync(p, encoding); }
function writeFileSync(p, data) { writeSync(p, data); }

const promises = {
  readFile: async (p, encoding) => readSync(p, encoding),
  writeFile: async (p, data) => writeSync(p, data),
  mkdir: async () => {},
  rename: async (a, b) => renameSync(a, b),
  unlink: async (p) => unlinkSync(p),
  copyFile: async (a, b) => copyFileSync(a, b),
  stat: async (p) => ({ isFile: () => existsSync(p), isDirectory: () => false }),
};

module.exports = {
  readFile: (p, enc, cb) => {
    try { cb(null, readSync(p, enc)); } catch (e) { cb(e); }
  },
  writeFile: (p, data, cb) => {
    try { writeSync(p, data); cb(null); } catch (e) { cb(e); }
  },
  existsSync,
  mkdirSync,
  copyFileSync,
  renameSync,
  unlinkSync,
  readFileSync,
  writeFileSync,
  promises,
};

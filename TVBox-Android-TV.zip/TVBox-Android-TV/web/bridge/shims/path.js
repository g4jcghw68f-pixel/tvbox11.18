// Browser shim for node:path (POSIX/Windows hybrid - paths are just keys here).
function normalize(p) { return String(p).replace(/\\/g, "/"); }
function join(...parts) {
  return parts
    .filter((p) => p !== undefined && p !== null && p !== "")
    .map(normalize)
    .join("/")
    .replace(/\/{2,}/g, "/");
}
function dirname(p) {
  const s = normalize(p);
  const i = s.lastIndexOf("/");
  if (i < 0) return ".";
  if (i === 0) return "/";
  return s.slice(0, i);
}
function basename(p, ext) {
  let s = normalize(p).split("/").pop() || "";
  if (ext && s.endsWith(ext)) s = s.slice(0, -ext.length);
  return s;
}
function extname(p) {
  const s = basename(p);
  const i = s.lastIndexOf(".");
  return i <= 0 ? "" : s.slice(i);
}
function resolve(...parts) { return join(...parts); }
function isAbsolute(p) { return normalize(p).startsWith("/"); }
function relative(from, to) { return normalize(to); }

module.exports = {
  join, dirname, basename, extname, resolve, isAbsolute, relative,
  normalize, sep: "/", delimiter: ":",
  parse: (p) => ({ dir: dirname(p), base: basename(p), ext: extname(p), name: basename(p, extname(p)) }),
};

// Browser shim for the "electron" module.
// Instead of real IPC, every ipcMain.handle(channel, fn) is registered into a
// JS map. The Android host injects `window.api` that calls these functions
// directly (async), preserving the exact same call contract as the desktop app.

const handlers = new Map();
const readyResolvers = [];
let appReady = false;

const ipcMain = {
  handle(channel, fn) {
    handlers.set(channel, fn);
  },
  on() {},
  once() {},
  removeHandler(channel) { handlers.delete(channel); },
};

// expose registry for the bridge to call
globalThis.__TVBOX_HANDLERS__ = handlers;

function getPath(name) {
  switch (name) {
    case "userData": return "/data/tvbox";
    case "sessionData": return "/data/tvbox/session";
    case "exe": return "/data/tvbox/TVBox";
    case "appData": return "/data/tvbox";
    case "home": return "/data";
    case "temp": return "/data/tvbox/tmp";
    default: return "/data/tvbox";
  }
}

const app = {
  isPackaged: true,
  getPath,
  setPath() {},
  getAppPath: () => "/data/tvbox",
  getVersion: () => "0.1.0",
  getName: () => "TVBox Desktop",
  setAppUserModelId() {},
  quit() {
    const b = globalThis.TVBoxBridge || globalThis.Android;
    if (b && typeof b.finish === "function") b.finish();
  },
  on(ev, fn) {
    // resolve when ready event would fire
    if (ev === "ready") { appReady = true; readyResolvers.splice(0).forEach((r) => r()); }
  },
  whenReady() {
    // The main process chains .then() on whenReady(); fire it on next tick,
    // after this module + main.process.js have finished registering handlers.
    return new Promise((resolve) => {
      setTimeout(() => {
        appReady = true;
        readyResolvers.splice(0).forEach((r) => r());
        resolve();
      }, 0);
    });
  },
};

const session = {
  defaultSession: {
    resolveProxy: async () => "DIRECT",
    setProxy: async () => {},
    webRequest: {
      onBeforeSendHeaders() {},
      onHeadersReceived() {},
    },
  },
};

const shell = {
  openExternal(url) {
    const b = globalThis.TVBoxBridge || globalThis.Android;
    try {
      if (b && typeof b.openExternal === "function") b.openExternal(String(url));
      else if (globalThis.window) globalThis.open(String(url), "_blank");
    } catch (e) { console.warn("[shell] openExternal failed", e); }
    return Promise.resolve();
  },
};

const dialog = {
  showOpenDialog: async () => {
    // File picking is delegated to native bridge; return cancelled if absent.
    const b = globalThis.TVBoxBridge || globalThis.Android;
    if (b && typeof b.pickFile === "function") {
      try {
        const path = await b.pickFile();
        return { canceled: !path, filePaths: path ? [path] : [] };
      } catch { /* fallthrough */ }
    }
    return { canceled: true, filePaths: [] };
  },
};

class BrowserWindow {
  constructor(options) {
    this.options = options || {};
    this.webContents = {
      send() {},
      setWindowOpenHandler() {},
      on() {},
      openDevTools() {},
    };
  }
  on() {}
  show() {}
  loadFile() {}
  loadURL() {}
  isDestroyed() { return false; }
  isMaximized() { return false; }
  isMinimized() { return false; }
  getSize() { return [1920, 1080]; }
  static getAllWindows() { return []; }
}

module.exports = {
  app, ipcMain, session, shell, dialog, BrowserWindow,
  contextBridge: { exposeInMainWorld() {} },
  ipcRenderer: { invoke() {}, on() {}, removeListener() {} },
};

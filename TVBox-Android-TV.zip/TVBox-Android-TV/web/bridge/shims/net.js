// Browser shim for node:net. Only used by "detectPlayers" local-port probing.
// On Android TV there is no local Windows player to probe; we fail fast so the
// feature degrades gracefully instead of hanging.
function connect(opts) {
  const listeners = {};
  const obj = {
    on(ev, fn) { (listeners[ev] ||= []).push(fn); return obj; },
    once(ev, fn) { (listeners[ev] ||= []).push(fn); return obj; },
    setNoDelay() {}, setKeepAlive() {}, setTimeout() {},
    destroy() {},
    write() {}, end() {},
    setTimeout2() {},
  };
  setTimeout(() => {
    const err = new Error("connect ECONNREFUSED (android)");
    err.code = "ECONNREFUSED";
    (listeners.error || []).forEach((fn) => fn(err));
    (listeners.close || []).forEach((fn) => fn());
  }, 30);
  return obj;
}

module.exports = { connect, createConnection: connect, isIP: () => 0 };

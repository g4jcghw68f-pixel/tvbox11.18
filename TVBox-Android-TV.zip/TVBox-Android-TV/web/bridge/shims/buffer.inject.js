// Global Buffer polyfill injected into every bundled module.
import { Buffer } from "buffer";
globalThis.Buffer = Buffer;
export { Buffer };

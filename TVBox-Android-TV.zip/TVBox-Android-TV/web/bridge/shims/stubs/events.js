// stub for browser bundle
module.exports = {};
module.exports.default = module.exports;

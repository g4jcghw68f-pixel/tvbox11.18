"use strict";
const electron = require("electron");
const IPC = {
  appInfo: "app:info",
  openExternal: "app:open-external",
  settingsGet: "settings:get",
  settingsSet: "settings:set",
  sourcesList: "sources:list",
  sourcesAdd: "sources:add",
  sourcesUpdate: "sources:update",
  sourcesRemove: "sources:remove",
  sourcesSync: "sources:sync",
  sourcesSyncAll: "sources:sync-all",
  sourcesPickFile: "sources:pick-file",
  sourcesPresets: "sources:presets",
  sourcesAddPreset: "sources:add-preset",
  sitesList: "sites:list",
  sitesSetEnabled: "sites:set-enabled",
  sitesSetAllEnabled: "sites:set-all-enabled",
  sitesTest: "sites:test",
  searchRun: "search:run",
  searchCancel: "search:cancel",
  /** 主进程 → 渲染进程：每完成一个站点推一次 */
  searchProgress: "search:progress",
  detailGet: "detail:get",
  categoryList: "category:list",
  categoryBrowse: "category:browse",
  liveLoad: "live:load",
  liveResolve: "live:resolve",
  /** 读线路体检缓存 */
  liveHealth: "live:health",
  /** 体检一批线路（点开频道时懒体检 / 切分组时预热） */
  liveProbe: "live:probe",
  liveClearHealth: "live:clear-health",
  libraryGet: "library:get",
  libraryToggleFavorite: "library:toggle-favorite",
  libraryRemoveFavorite: "library:remove-favorite",
  libraryClearFavorites: "library:clear-favorites",
  libraryRecord: "library:record",
  libraryRemoveHistory: "library:remove-history-group",
  libraryClearHistory: "library:clear-history",
  playerDetect: "player:detect",
  playerOpen: "player:open",
  parseList: "parse:list",
  parseResolve: "parse:resolve",
  parseTest: "parse:test",
  parseAdd: "parse:add",
  parseRemove: "parse:remove",
  parseResetStats: "parse:reset-stats",
  /** 首页内容位。force=true 时忽略缓存重新拉一遍 */
  homeSections: "home:sections",
  aiSummary: "ai:summary",
  /** 带上从播放器里抽出来的画面，让模型真的看一遍 */
  aiSummaryVisual: "ai:summary-visual"
};
const api = {
  info: () => electron.ipcRenderer.invoke(IPC.appInfo),
  openExternal: (url) => electron.ipcRenderer.invoke(IPC.openExternal, url),
  settings: {
    get: () => electron.ipcRenderer.invoke(IPC.settingsGet),
    set: (patch) => electron.ipcRenderer.invoke(IPC.settingsSet, patch)
  },
  sources: {
    list: () => electron.ipcRenderer.invoke(IPC.sourcesList),
    add: (input) => electron.ipcRenderer.invoke(IPC.sourcesAdd, input),
    update: (id, patch) => electron.ipcRenderer.invoke(IPC.sourcesUpdate, id, patch),
    remove: (id) => electron.ipcRenderer.invoke(IPC.sourcesRemove, id),
    sync: (id) => electron.ipcRenderer.invoke(IPC.sourcesSync, id),
    syncAll: () => electron.ipcRenderer.invoke(IPC.sourcesSyncAll),
    pickFile: () => electron.ipcRenderer.invoke(IPC.sourcesPickFile),
    presets: () => electron.ipcRenderer.invoke(IPC.sourcesPresets),
    addPreset: (id) => electron.ipcRenderer.invoke(IPC.sourcesAddPreset, id)
  },
  sites: {
    list: () => electron.ipcRenderer.invoke(IPC.sitesList),
    setEnabled: (key, enabled) => electron.ipcRenderer.invoke(IPC.sitesSetEnabled, key, enabled),
    setAllEnabled: (keys, enabled) => electron.ipcRenderer.invoke(IPC.sitesSetAllEnabled, keys, enabled),
    test: (key) => electron.ipcRenderer.invoke(IPC.sitesTest, key)
  },
  search: {
    run: (wd, options) => electron.ipcRenderer.invoke(IPC.searchRun, wd, options),
    cancel: () => electron.ipcRenderer.invoke(IPC.searchCancel),
    /** 订阅进度事件，返回取消订阅的函数 */
    onProgress: (cb) => {
      const listener = (_e, progress) => cb(progress);
      electron.ipcRenderer.on(IPC.searchProgress, listener);
      return () => {
        electron.ipcRenderer.removeListener(IPC.searchProgress, listener);
      };
    }
  },
  detail: {
    get: (siteKey, vodId) => electron.ipcRenderer.invoke(IPC.detailGet, siteKey, vodId)
  },
  category: {
    list: () => electron.ipcRenderer.invoke(IPC.categoryList),
    browse: (bucket, sub = "", page = 1) => electron.ipcRenderer.invoke(IPC.categoryBrowse, bucket, sub, page)
  },
  home: {
    /** 首页内容位。force=true 时忽略 10 分钟缓存重新拉 */
    sections: (force = false) => electron.ipcRenderer.invoke(IPC.homeSections, force)
  },
  live: {
    load: (force = false) => electron.ipcRenderer.invoke(IPC.liveLoad, force),
    resolve: (url) => electron.ipcRenderer.invoke(IPC.liveResolve, url),
    health: () => electron.ipcRenderer.invoke(IPC.liveHealth),
    probe: (urls, options) => electron.ipcRenderer.invoke(IPC.liveProbe, urls, options),
    clearHealth: () => electron.ipcRenderer.invoke(IPC.liveClearHealth)
  },
  library: {
    get: () => electron.ipcRenderer.invoke(IPC.libraryGet),
    toggleFavorite: (input) => electron.ipcRenderer.invoke(IPC.libraryToggleFavorite, input),
    removeFavorite: (key) => electron.ipcRenderer.invoke(IPC.libraryRemoveFavorite, key),
    clearFavorites: () => electron.ipcRenderer.invoke(IPC.libraryClearFavorites),
    record: (input) => electron.ipcRenderer.invoke(IPC.libraryRecord, input),
    /** key 是归一化片名（HistoryGroup.key），会删掉这部片在所有源上的记录 */
    removeHistory: (key) => electron.ipcRenderer.invoke(IPC.libraryRemoveHistory, key),
    clearHistory: () => electron.ipcRenderer.invoke(IPC.libraryClearHistory)
  },
  player: {
    detect: () => electron.ipcRenderer.invoke(IPC.playerDetect),
    open: (url, title) => electron.ipcRenderer.invoke(IPC.playerOpen, url, title)
  },
  parse: {
    list: () => electron.ipcRenderer.invoke(IPC.parseList),
    /** 网页型地址走解析换直链；直链会原样返回（direct=true） */
    resolve: (url, options) => electron.ipcRenderer.invoke(IPC.parseResolve, url, options ?? {}),
    test: (url, target) => electron.ipcRenderer.invoke(IPC.parseTest, url, target),
    add: (input) => electron.ipcRenderer.invoke(IPC.parseAdd, input),
    remove: (url) => electron.ipcRenderer.invoke(IPC.parseRemove, url),
    resetStats: () => electron.ipcRenderer.invoke(IPC.parseResetStats)
  },
  ai: {
    summarize: (input) => electron.ipcRenderer.invoke(IPC.aiSummary, input),
    /** frames 是渲染进程从 <video> 抽的帧，走 IPC 传给主进程拼成多模态请求 */
    summarizeVisual: (input, frames) => electron.ipcRenderer.invoke(IPC.aiSummaryVisual, input, frames)
  }
};
electron.contextBridge.exposeInMainWorld("api", api);

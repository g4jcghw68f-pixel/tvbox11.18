# No code shrinking for the debug/TV build.
# Keep JavaScript bridge methods if minify is ever enabled.
-keepclassmembers class com.tvbox.androidtv.MainActivity$TVBoxBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

/* TVBox TV - remote control (DPAD) navigation for a mouse-oriented React UI.
 * Android sends arrow keys / Enter / Back as standard KeyboardEvents.
 * We implement spatial-ish focus navigation over focusable DOM elements,
 * auto-focus the first element on load, and map Back to history/back handling.
 */
(function () {
  var FOCUSABLE = [
    'a[href]', 'button:not([disabled])', 'input:not([disabled])',
    'select:not([disabled])', 'textarea:not([disabled])',
    '[tabindex]:not([tabindex="-1"])', '[role="button"]', '[role="tab"]',
    '[role="menuitem"]', '[role="link"]', 'li[clickable]'
  ].join(',');

  function visible(el) {
    if (!el) return false;
    var s = getComputedStyle(el);
    if (s.display === 'none' || s.visibility === 'hidden' || parseFloat(s.opacity || '1') < 0.1) return false;
    var r = el.getBoundingClientRect();
    return r.width > 2 && r.height > 2;
  }

  function focusables() {
    return Array.prototype.filter.call(document.querySelectorAll(FOCUSABLE), visible);
  }

  function center(el) {
    var r = el.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2, r: r };
  }

  // Pick the next focusable in a direction using geometric scoring.
  function moveFocus(dir) {
    var list = focusables();
    if (!list.length) return;
    var cur = document.activeElement;
    if (!cur || cur === document.body || list.indexOf(cur) === -1) {
      (dir === 'up' ? list[list.length - 1] : list[0]).focus();
      return;
    }
    var a = center(cur);
    var best = null, bestScore = Infinity;
    list.forEach(function (el) {
      if (el === cur) return;
      var b = center(el);
      var dx = b.x - a.x, dy = b.y - a.y;
      var primary = dir === 'right' ? dx : dir === 'left' ? -dx : dir === 'down' ? dy : -dy;
      if (primary <= 4) return; // must be in the requested direction
      var cross = dir === 'left' || dir === 'right' ? Math.abs(dy) : Math.abs(dx);
      var score = primary + cross * 2.2;
      // mild penalty for far vertical jumps on horizontal move
      if (score < bestScore) { bestScore = score; best = el; }
    });
    if (best) {
      best.focus();
      try { best.scrollIntoView({ block: 'nearest', inline: 'nearest' }); } catch (e) {}
    }
  }

  function onKey(e) {
    var k = e.key;
    var handled = true;
    switch (k) {
      case 'ArrowRight': moveFocus('right'); break;
      case 'ArrowLeft': moveFocus('left'); break;
      case 'ArrowDown': moveFocus('down'); break;
      case 'ArrowUp': moveFocus('up'); break;
      case 'Enter':
      case ' ':
        // let native button/link activation work; trigger click for role-based items
        var el = document.activeElement;
        if (el && el.hasAttribute && el.hasAttribute('role') && typeof el.click === 'function') {
          el.click();
        }
        break;
      case 'Backspace':
      case 'Escape':
        handled = false; // let native Android back (bridge) handle it
        break;
      default:
        handled = false;
    }
    if (handled) { e.preventDefault(); e.stopPropagation(); }
  }

  window.TVBoxInitRemote = function () {
    document.addEventListener('keydown', onKey, true);
    // focus first meaningful element after each route/content change
    var scheduleFocus = function () {
      setTimeout(function () {
        if (document.activeElement && document.activeElement !== document.body) return;
        var list = focusables();
        if (list.length) list[0].focus();
      }, 60);
    };
    scheduleFocus();
    var obs = new MutationObserver(function () {
      if (!document.activeElement || document.activeElement === document.body) scheduleFocus();
    });
    obs.observe(document.getElementById('root') || document.body, { childList: true, subtree: true });
  };
})();

// Bridge: reconstructs window.api exactly as preload/index.js did, but calls
// the in-page main-process handlers directly instead of going through Electron IPC.
(function () {
  const H = globalThis.__TVBOX_HANDLERS__ || new Map();
  function invoke(channel, ...args) {
    const fn = H.get(channel);
    if (!fn) {
      console.warn("[bridge] no handler for", channel);
      return Promise.reject(new Error("未实现的接口: " + channel));
    }
    try {
      return Promise.resolve(fn({}, ...args));
    } catch (e) {
      return Promise.reject(e);
    }
  }
  const IPC = {
    appInfo: "app:info", openExternal: "app:open-external",
    settingsGet: "settings:get", settingsSet: "settings:set",
    sourcesList: "sources:list", sourcesAdd: "sources:add", sourcesUpdate: "sources:update",
    sourcesRemove: "sources:remove", sourcesSync: "sources:sync", sourcesSyncAll: "sources:sync-all",
    sourcesPickFile: "sources:pick-file", sourcesPresets: "sources:presets", sourcesAddPreset: "sources:add-preset",
    sitesList: "sites:list", sitesSetEnabled: "sites:set-enabled", sitesSetAllEnabled: "sites:set-all-enabled", sitesTest: "sites:test",
    searchRun: "search:run", searchCancel: "search:cancel", searchProgress: "search:progress",
    detailGet: "detail:get", categoryList: "category:list", categoryBrowse: "category:browse",
    liveLoad: "live:load", liveResolve: "live:resolve", liveHealth: "live:health", liveProbe: "live:probe", liveClearHealth: "live:clear-health",
    libraryGet: "library:get", libraryToggleFavorite: "library:toggle-favorite",
    libraryRemoveFavorite: "library:remove-favorite", libraryClearFavorites: "library:clear-favorites",
    libraryRecord: "library:record", libraryRemoveHistory: "library:remove-history-group", libraryClearHistory: "library:clear-history",
    playerDetect: "player:detect", playerOpen: "player:open",
    parseList: "parse:list", parseResolve: "parse:resolve", parseTest: "parse:test",
    parseAdd: "parse:add", parseRemove: "parse:remove", parseResetStats: "parse:reset-stats",
    homeSections: "home:sections", aiSummary: "ai:summary", aiSummaryVisual: "ai:summary-visual",
  };

  const api = {
    info: () => invoke(IPC.appInfo),
    openExternal: (url) => invoke(IPC.openExternal, url),
    settings: {
      get: () => invoke(IPC.settingsGet),
      set: (patch) => invoke(IPC.settingsSet, patch),
    },
    sources: {
      list: () => invoke(IPC.sourcesList),
      add: (input) => invoke(IPC.sourcesAdd, input),
      update: (id, patch) => invoke(IPC.sourcesUpdate, id, patch),
      remove: (id) => invoke(IPC.sourcesRemove, id),
      sync: (id) => invoke(IPC.sourcesSync, id),
      syncAll: () => invoke(IPC.sourcesSyncAll),
      pickFile: () => invoke(IPC.sourcesPickFile),
      presets: () => invoke(IPC.sourcesPresets),
      addPreset: (id) => invoke(IPC.sourcesAddPreset, id),
    },
    sites: {
      list: () => invoke(IPC.sitesList),
      setEnabled: (key, enabled) => invoke(IPC.sitesSetEnabled, key, enabled),
      setAllEnabled: (keys, enabled) => invoke(IPC.sitesSetAllEnabled, keys, enabled),
      test: (key) => invoke(IPC.sitesTest, key),
    },
    search: {
      run: (wd, options) => invoke(IPC.searchRun, wd, options),
      cancel: () => invoke(IPC.searchCancel),
      onProgress: (cb) => {
        // main process sends progress via mainWindow.webContents.send; in shim
        // it is emitted as a CustomEvent on window.
        const listener = (e) => cb(e.detail);
        window.addEventListener("tvbox:search-progress", listener);
        return () => window.removeEventListener("tvbox:search-progress", listener);
      },
    },
    detail: { get: (siteKey, vodId) => invoke(IPC.detailGet, siteKey, vodId) },
    category: {
      list: () => invoke(IPC.categoryList),
      browse: (bucket, sub = "", page = 1) => invoke(IPC.categoryBrowse, bucket, sub, page),
    },
    home: { sections: (force = false) => invoke(IPC.homeSections, force) },
    live: {
      load: (force = false) => invoke(IPC.liveLoad, force),
      resolve: (url) => invoke(IPC.liveResolve, url),
      health: () => invoke(IPC.liveHealth),
      probe: (urls, options) => invoke(IPC.liveProbe, urls, options),
      clearHealth: () => invoke(IPC.liveClearHealth),
    },
    library: {
      get: () => invoke(IPC.libraryGet),
      toggleFavorite: (input) => invoke(IPC.libraryToggleFavorite, input),
      removeFavorite: (key) => invoke(IPC.libraryRemoveFavorite, key),
      clearFavorites: () => invoke(IPC.libraryClearFavorites),
      record: (input) => invoke(IPC.libraryRecord, input),
      removeHistory: (key) => invoke(IPC.libraryRemoveHistory, key),
      clearHistory: () => invoke(IPC.libraryClearHistory),
    },
    player: {
      detect: () => invoke(IPC.playerDetect),
      open: (url, title) => invoke(IPC.playerOpen, url, title),
    },
    parse: {
      list: () => invoke(IPC.parseList),
      resolve: (url, options) => invoke(IPC.parseResolve, url, options ?? {}),
      test: (url, target) => invoke(IPC.parseTest, url, target),
      add: (input) => invoke(IPC.parseAdd, input),
      remove: (url) => invoke(IPC.parseRemove, url),
      resetStats: () => invoke(IPC.parseResetStats),
    },
    ai: {
      summarize: (input) => invoke(IPC.aiSummary, input),
      summarizeVisual: (input, frames) => invoke(IPC.aiSummaryVisual, input, frames),
    },
  };
  window.api = api;
  globalThis.__TVBOX_API__ = api;
})();

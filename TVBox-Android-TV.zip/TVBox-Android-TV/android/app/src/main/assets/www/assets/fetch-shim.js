(function(){
  var pending = {};
  var seq = 0;
  window.__tvboxHttpCb = function(id, status, statusText, headersJson, bodyB64){
    var p = pending[id]; if(!p) return; delete pending[id];
    var bytes;
    try {
      var bin = atob(bodyB64);
      bytes = new Uint8Array(bin.length);
      for (var i=0;i<bin.length;i++) bytes[i]=bin.charCodeAt(i);
    } catch(e){ bytes = new Uint8Array(0); }
    var headers = {};
    try { headers = JSON.parse(headersJson)||{}; } catch(e){}
    var h = new Headers();
    Object.keys(headers).forEach(function(k){ try{ h.set(k, headers[k]); }catch(e){} });
    var init = { status: status||0, statusText: statusText||'', headers: h };
    var resp = new Response(bytes.buffer, init);
    Object.defineProperty(resp, 'url', { value: p.url });
    Object.defineProperty(resp, 'ok', { value: status>=200 && status<300 });
    p.resolve(resp);
  };
  window.fetch = function(input, init){
    init = init || {};
    var url = typeof input === 'string' ? input : (input && input.url) || String(input);
    var method = (init.method || 'GET').toUpperCase();
    var headers = {};
    if (init.headers) {
      if (init.headers.forEach) init.headers.forEach(function(v,k){ headers[k]=v; });
      else Object.keys(init.headers).forEach(function(k){ headers[k]=init.headers[k]; });
    }
    var bodyB64 = '';
    if (init.body) {
      try {
        var b = init.body;
        if (typeof b === 'string') {
          var bin=''; for(var i=0;i<b.length;i++) bin+=String.fromCharCode(b.charCodeAt(i)&0xff);
          bodyB64 = btoa(bin);
        } else if (b instanceof ArrayBuffer) {
          var u=new Uint8Array(b), s=''; for(var j=0;j<u.length;j++) s+=String.fromCharCode(u[j]);
          bodyB64=btoa(s);
        }
      } catch(e){}
    }
    var timeout = 20000;
    if (init.signal && init.signal.aborted) return Promise.reject(new Error('aborted'));
    var id = 'r'+(++seq);
    return new Promise(function(resolve, reject){ pending[id]={resolve:resolve,reject:reject,url:url};
      try { window.TVBoxBridge.httpRequest(id, url, method, JSON.stringify(headers), bodyB64, timeout); }
      catch(e){ delete pending[id]; reject(e); }
    });
  };
})();

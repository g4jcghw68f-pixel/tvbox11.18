package com.tvbox.androidtv

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.*
import kotlinx.coroutines.*

/**
 * TVBox Android TV - WebView host.
 * Loads the ported React UI + Node main-process bundle and exposes a JS bridge
 * that replaces the desktop-only Electron capabilities (network, external
 * player, file picker, exit).
 */
class MainActivity : Activity(), CoroutineScope by MainScope() {

    private lateinit var webView: WebView
    private val TAG = "TVBoxTV"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                allowFileAccessFromFileURLs = true
                allowUniversalAccessFromFileURLs = true
                mediaPlaybackRequiresUserGesture = false
                javaScriptCanOpenWindowsAutomatically = true
                setSupportMultipleWindows(true)
                loadWithOverviewMode = true
                useWideViewPort = true
                builtInZoomControls = false
                displayZoomControls = false
                // Desktop UA so source sites serve the same HTML as the PC app
                userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
                cacheMode = WebSettings.LOAD_DEFAULT
            }
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    Log.d(TAG, "page finished: $url")
                }
                override fun onReceivedError(view: WebView?, request: WebRequest?, error: WebResourceError?) {
                    Log.e(TAG, "page error: ${error?.description}")
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(msg: ConsoleMessage?): Boolean {
                    Log.d(TAG, "JS: ${msg?.message()} @${msg?.lineNumber()}")
                    return true
                }
            }
            addJavascriptInterface(TVBoxBridge(), "TVBoxBridge")
            addJavascriptInterface(TVBoxBridge(), "Android")
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
        }
        setContentView(webView)

        // fetch polyfill is loaded first from assets/fetch-shim.js in index.html
        webView.loadUrl("file:///android_asset/www/index.html")
    }

    /** Native bridge exposed to JS as window.TVBoxBridge */
    inner class TVBoxBridge {
        @JavascriptInterface
        fun openExternal(url: String) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            } catch (e: Exception) {
                Log.e(TAG, "openExternal failed: ${e.message}")
            }
        }

        @JavascriptInterface
        fun finish() {
            this@MainActivity.finish()
        }

        @JavascriptInterface
        fun log(msg: String) {
            Log.d(TAG, msg)
        }

        /**
         * Perform a network request natively (bypasses WebView CORS).
         * Returns via callback: window.__tvboxHttpCb(reqId, status, statusText, headersJson, bodyBase64)
         */
        @JavascriptInterface
        fun httpRequest(reqId: String, url: String, method: String, headersJson: String, bodyBase64: String, timeoutMs: Int) {
            launch(Dispatchers.IO) {
                try {
                    val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                    conn.requestMethod = method
                    conn.connectTimeout = timeoutMs
                    conn.readTimeout = timeoutMs
                    conn.instanceFollowRedirects = true
                    if (headersJson.isNotBlank()) {
                        val headers = org.json.JSONObject(headersJson)
                        headers.keys().forEach { key ->
                            conn.setRequestProperty(key, headers.getString(key))
                        }
                    }
                    if (bodyBase64.isNotBlank() && method != "GET") {
                        val body = android.util.Base64.decode(bodyBase64, android.util.Base64.DEFAULT)
                        conn.doOutput = true
                        conn.outputStream.use { it.write(body) }
                    }
                    val status = conn.responseCode
                    val stream = if (status in 200..399) conn.inputStream else conn.errorStream
                    val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
                    val headers = org.json.JSONObject().apply {
                        conn.headerFields.forEach { (k, v) ->
                            if (k != null && v.isNotEmpty()) put(k, v.joinToString(", "))
                        }
                    }
                    val reason = try { conn.responseMessage } catch (e: Exception) { "" }
                    val bodyB64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                    conn.disconnect()
                    withContext(Dispatchers.Main) {
                        webView.evaluateJavascript(
                            "window.__tvboxHttpCb && window.__tvboxHttpCb('$reqId',$status,'${esc(reason)}','${esc(headers.toString())}','$bodyB64')",
                            null
                        )
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        webView.evaluateJavascript(
                            "window.__tvboxHttpCb && window.__tvboxHttpCb('$reqId',0,'${esc(e.message ?: "error")}','{}','')",
                            null
                        )
                    }
                }
            }
        }

        private fun esc(s: String) = s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // Let the WebView (and tv-nav.js) handle DPAD navigation first.
        return super.dispatchKeyEvent(event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        webView.evaluateJavascript(
            "(function(){var e=new KeyboardEvent('keydown',{key:'Escape',bubbles:true});document.dispatchEvent(e);return !!window.__tvboxHandledBack;})()"
        ) { result ->
            // If the page didn't handle it, exit app
            if (result == "false" || result == "null" || result == null) {
                finish()
            }
        }
    }

    override fun onDestroy() {
        cancel()
        super.onDestroy()
    }

}
